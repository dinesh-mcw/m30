#pragma once

#include "RawToDepth.h"
#include "RawToDepthPlatform.h"
#include "ProcessRoiThread.h"

class RawToDepthV2_opencl : public RawToDepth
{
 protected:

  RawToDepthPlatform _platform;
  ProcessRoiThread _processRoiThread;
  std::shared_ptr<std::vector<uint16_t>>    _signals;
  std::shared_ptr<std::vector<uint16_t>>    _background;
  std::shared_ptr<std::vector<uint16_t>>    _snr;   
  std::shared_ptr<std::vector<uint16_t>>    _ranges; // integer in 1/1024 meters per step
  
  // convolution kernel indices for smoothing the raw frame buffer.
  uint32_t _rowKernelIdx = 1; 
  uint32_t _columnKernelIdx = 1;

public:
  RawToDepthV2_opencl(uint32_t fovIdx=0, uint32_t headerNum=0);
  virtual std::shared_ptr<std::vector<uint16_t>> getRange() const override;
  virtual std::shared_ptr<std::vector<uint16_t>> getSnrSquared() const override;
  virtual std::shared_ptr<std::vector<uint16_t>> getSignal() const override;
  virtual std::shared_ptr<std::vector<uint16_t>> getBackground() const override;
  virtual std::shared_ptr<std::vector<uint16_t>> getSnr() const override;
  
  void processRoi(uint16_t* roi, uint32_t numBytes) override;
  void processWholeFrame() override;
  static void smoothSummedData(const RtdVec &roiSummed, RtdVec &roiSmoothed, std::vector<uint32_t> size,
															 uint32_t _rowKernelIdx, uint32_t _columnKernelIdx, uint32_t frqIdx, RawToDepthPlatform &platform);
  static void smoothRaw3x5(const RtdVec &dFrameBuffer, RtdVec &dFrameBufferSmoothed, std::vector<uint32_t> frameSize, uint32_t frqIdx, RawToDepthPlatform &platform);
  static void smoothRaw5x7(const RtdVec &dFrameBuffer, RtdVec &dFrameSmoothed, std::vector<uint32_t> frameSize, uint32_t frqIdx, RawToDepthPlatform &platform);
  static void smoothRaw7x15(const RtdVec &dFrameBuffer, RtdVec &dFrameSmoothed, std::vector<uint32_t> frameSize, uint32_t frqIdx, RawToDepthPlatform &platform);


  void reset(uint16_t *md, uint32_t mdBytes) override;
  virtual void loadPixelMask(std::string pixelMaskFilename = "") override ;

private:
  void realloc(uint16_t *md, uint32_t mdBytes);

};
