#include "RawToDepthPlatform.h"
#include "OpenCLSmooth3RawKernel.h"
#include "OpenCLSmooth5RawKernel.h"
#include "OpenCLSmooth7RawKernel.h"
#include "OpenCLSmooth15RawKernel.h"
#include "OpenCLTransposeRawKernel.h"
#include "OpenCLCalcPhaseSmoothKernel.h"
#include "OpenCLComputeWholeFrameRangeKernel.h"
#include "OpenCLMinMaxKernel.h"
#include "OpenCLMedianFilterPlusKernel.h"
#include "OpenCLMedianPlus2x3Kernel.h"
#include "OpenCLMedianPlus5x7Kernel.h"
#include "OpenCLProcessRoiKernel.h"
#include "LumoLogger.h"
#include "RtdVec.h"
#include <CL/cl.h>

RawToDepthPlatform::RawToDepthPlatform(unsigned int logLevel) :
  _vecs(_gpuProps),
  _kernels(_gpuProps),
  _staticBuffers(_gpuProps)
{
  if (0 <= logLevel)
  {
      LLogSetDebugLevel(logLevel);
  }

  // Eager compilation of OpenCL Kernel code.
  auto phaseSmoothKernel = OpenCLCalcPhaseSmoothKernel(this->getKernels());
  auto computeWholeFrameRangeKernel= OpenCLComputeWholeFrameRangeKernel(this->getKernels());
  auto medianFilterPlus = OpenCLMedianFilterPlusKernel(this->getKernels());
  auto median2x3Filter = OpenCLMedianPlus2x3Kernel(this->getKernels());
  auto median5x7Filter = OpenCLMedianPlus5x7Kernel(this->getKernels());
  auto minMaxKernel = OpenCLMinMaxKernel(this->getKernels());
  auto smooth3Kernel = OpenCLSmooth3RawKernel(this->getKernels());
  auto smooth5Kernel = OpenCLSmooth5RawKernel(this->getKernels());
  auto smooth7Kernel = OpenCLSmooth7RawKernel(this->getKernels());
  auto smooth15Kernel = OpenCLSmooth15RawKernel(this->getKernels());
  auto transposeRawKernel = OpenCLTransposeRawKernel(this->getKernels());
  auto processRoiKernel = OpenCLProcessRoiKernel(this->getKernels());
}

RawToDepthPlatform::~RawToDepthPlatform() 
{
  clReleaseCommandQueue(_gpuProps.commandQueue);
  clReleaseContext(_gpuProps.openclContext);
}

