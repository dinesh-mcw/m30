#pragma once

// Core calculate phase macro.
#define CALCULATE_PHASE_FUNCTION "  \n\
#define calculate_phase(a_, b_, c_, phase, signal, background, snr, binningFactor) {  \\\n\
  float a = a_, b = b_, c = c_;                                \\\n\
  const float oneThird=1.0F/3.0F;                               \\\n\
  const float twoThirds=2.0F/3.0F;                              \\\n\
  float frac = 0;                                               \\\n\
                                                                \\\n\
  if (a <= b && a <= c)                                         \\\n\
  {                                                             \\\n\
    float tmp = c;                                              \\\n\
    c = a;                                                      \\\n\
    a = b;                                                      \\\n\
    b = tmp;                                                    \\\n\
    frac = oneThird;                                            \\\n\
  }                                                             \\\n\
                                                                \\\n\
  else if (b <= c && b < a)                                     \\\n\
  {                                                             \\\n\
    float tmp = a;                                              \\\n\
    a = c;                                                      \\\n\
    c = b;                                                      \\\n\
    b = tmp;                                                    \\\n\
    frac = twoThirds;                                           \\\n\
  }                                                             \\\n\
                                                                \\\n\
  signal = a + b - 2 * c;                                       \\\n\
  if (signal <= 0)                                              \\\n\
    signal = 1;                                                 \\\n\
                                                                \\\n\
  float part1 = b-c;                                            \\\n\
  float part2 = oneThird * (part1 / signal) + frac;             \\\n\
                                                                \\\n\
  phase = part2;                                                \\\n\
                                                                \\\n\
  if (c< 1/65535.0F) c = 1/65535.0F;                            \\\n\
  snr = binningFactor * signal / native_sqrt(2.0F * c);         \\\n\
  background = c;                                               \\\n\
}"

