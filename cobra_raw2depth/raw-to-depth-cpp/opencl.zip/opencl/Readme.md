# raw-to-depth-cpp/opencl directory.

This code was developed for benchmarking against very small NXP processors with a GPU.
It has not been kept up-to-date with the current RawToDepth algorithm set.