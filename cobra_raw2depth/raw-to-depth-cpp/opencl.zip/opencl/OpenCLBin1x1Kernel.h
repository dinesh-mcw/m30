#pragma once

// Core 1x1 binning function.
#define BIN_1X1_FUNCTION " \n\
inline float3 bin_1x1(const __global float *in, int x, int y, int outputWidth) { \n\
  int inputIndex = x + outputWidth*y;  \n\
  float3 a = vload3(inputIndex, in);  \n\
  return a;  \n\
}  \n"
