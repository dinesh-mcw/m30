#pragma once
#include "OpenCLKernel.h"
#include "OpenCLKernels.h"
#include <memory>
#include <RtdVec.h>
#include <cstdint>

// Plus-shaped median filter with fixed 2x3 size.
class OpenCLMedianPlus2x3Kernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_median_2x3_code;
  static const char *cl_median_2x3_name;

public:
  OpenCLMedianPlus2x3Kernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &dIn, RtdVec &dOut, std::vector<uint32_t> frameSize, bool performGhostMedian);
};