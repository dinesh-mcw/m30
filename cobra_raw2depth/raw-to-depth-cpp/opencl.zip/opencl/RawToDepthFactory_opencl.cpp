#include "RawToDepthFactory.h"
#include "RawToDepthV2_opencl.h"

std::unique_ptr<RawToDepth> RawToDepthFactory::create(uint32_t fovIdx, uint32_t headerNum) 
{
   return std::make_unique<RawToDepthV2_opencl>(fovIdx, headerNum);
}