#pragma once
#include "OpenCLProfile.h"
#include <memory>
#include <vector>

// Gathers GPU timers.
class OpenCLProfiler
{
private:
  std::vector<std::shared_ptr<OpenCLProfile>> _profiles; // one per tag.

public: 
  std::shared_ptr<OpenCLProfile> get(const std::string tag);
  ~OpenCLProfiler();
};


