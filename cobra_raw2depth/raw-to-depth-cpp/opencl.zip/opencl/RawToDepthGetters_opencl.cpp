
#include "RawToDepthV2_opencl.h"

std::shared_ptr<std::vector<uint16_t>> RawToDepthV2_opencl::getRange() const
{
  if (_disableStreaming || !_firstRoiReceived ||
      !imageComplete())
    return nullptr;
  
  return _ranges;
}


std::shared_ptr<std::vector<uint16_t>> RawToDepthV2_opencl::getSignal() const
{
  if (_disableStreaming || !_firstRoiReceived || 
      !imageComplete())
    return nullptr;

  return _signals;
}


std::shared_ptr<std::vector<uint16_t>> RawToDepthV2_opencl::getBackground() const
{
  if (_disableStreaming || !_firstRoiReceived || 
      !imageComplete())
    return nullptr;

  return _background;
}

std::shared_ptr<std::vector<uint16_t>> RawToDepthV2_opencl::getSnrSquared() const {
  return getSnr();
}


std::shared_ptr<std::vector<uint16_t>> RawToDepthV2_opencl::getSnr() const {

  if (_disableStreaming || !_firstRoiReceived || 
      !imageComplete())
    return nullptr;

  return _snr;
}
