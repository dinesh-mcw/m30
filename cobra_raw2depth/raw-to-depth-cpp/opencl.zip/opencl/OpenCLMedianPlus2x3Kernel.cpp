#include "OpenCLMedianPlus2x3Kernel.h"
#include "LumoUtil.h"

const char *OpenCLMedianPlus2x3Kernel::cl_median_2x3_code = "  \n\
#define hMargin 2  \n\
#define vMargin 1  \n\
#define insert(a, points, idx) \\\n\
  {  \\\n\
    int iidx=0; \\\n\
    while(iidx<idx) { \\\n\
      if (a > points[iidx]) break; \\\n\
      iidx++; \\\n\
    } \\\n\
    int sidx = idx; \\\n\
    while (sidx > iidx) { points[sidx] = points[sidx-1]; sidx--; } \\\n\
    points[iidx] = a; \\\n\
  } \\\n\
  \n\
__kernel void cl_median_2x3( const __global float *in, \n\
                             __global float *out,  \n\
                             int frameWidth,  \n\
                             int frameHeight,  \n\
                             int performGhostMedian) {  \n\
  int work_dim = (int)get_work_dim(); \n\
  float points[7];  \n\
  if (work_dim != 2) return;  \n\
  int x = get_global_id(0);  \n\
  int y = get_global_id(1);  \n\
  if (x >= frameWidth || y >= frameHeight) return;  \n\
  int index = x + y*frameWidth;  \n\
  float a = in[index];  \n\
  if (0 == performGhostMedian || x < hMargin || y < vMargin || x >= frameWidth-hMargin || y >= frameHeight-vMargin) {  \n\
    out[index] = a;  \n\
    return;  \n\
  }  \n\
  // insert a into points  \n\
  insert(a, points, 0); \n\
  a = in[index-frameWidth];   \n\
  insert(a, points, 1);  \n\
  a = in[index+frameWidth];  \n\
  insert(a, points, 2);  \n\
  a = in[index-2];   \n\
  insert(a, points, 3);  \n\
  a = in[index-1];   \n\
  insert(a, points, 4);  \n\
  a = in[index+1];  \n\
  insert(a, points, 5);  \n\
  a = in[index+2];   \n\
  insert(a, points, 6);  \n\
  out[index] = points[3];  \n\
  \n\
}";;
const char *OpenCLMedianPlus2x3Kernel::cl_median_2x3_name = "cl_median_2x3";

OpenCLMedianPlus2x3Kernel::OpenCLMedianPlus2x3Kernel(OpenCLKernels &kernels) : 
  _openCLKernel(kernels.getKernel(cl_median_2x3_name, cl_median_2x3_code))
{
}

void OpenCLMedianPlus2x3Kernel::enqueue(RtdVec &dIn, RtdVec &dOut, std::vector<uint32_t> frameSize, bool performGhostMedian)
{
  cl_int res;
  cl_int frameWidth = frameSize[1];
  cl_int frameHeight = frameSize[0];
  cl_int iPerformGhostMedian = (cl_int)performGhostMedian;

  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&dIn.vec));
  RtdVec::errorCheck(res, "OpenCLMedianPlus2x3Kernel::enqueue() - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&dOut.vec));
  RtdVec::errorCheck(res, "OpenCLMedianPlus2x3Kernel::enqueue() - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_int), (void*)(&frameWidth));
  RtdVec::errorCheck(res, "OpenCLMedianPlus2x3Kernel::enqueue() - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(cl_int), (void*)(&frameHeight));
  RtdVec::errorCheck(res, "OpenCLMedianPlus2x3Kernel::enqueue() - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(cl_int), (void*)(&iPerformGhostMedian));
  RtdVec::errorCheck(res, "OpenCLMedianPlus2x3Kernel::enqueue() - clSetKernelArg 4");

  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8, 4};
  // The number of raw-triplet pixels processed in the image excludes the padding
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(frameWidth, local_work_size[0]),
                                LumoUtil::roundToMultiple(frameHeight, local_work_size[1])};
  
  cl_event event;
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), 2, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLMedianPlus2x3Kernel::enqueue() - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLMedianPlus2x3Kernel")->add(event);

}