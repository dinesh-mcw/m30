#include "OpenCLMaskKernel.h"
#include "OpenCLStaticBuffers.h"
#include "LumoUtil.h"


struct Dims 
{
  cl_int frameWidth;
  cl_int frameHeight;
  cl_float snrThresh;
  cl_int disableRangeMasking;
  cl_float maxRangeThresh;
  cl_int pixelMaskStartX;
  cl_int pixelMaskStartY;
  cl_int pixelMaskStepX;
  cl_int pixelMaskStepY;
  cl_int pixelMaskString;
};

// 1-D kernel.
const char *OpenCLMaskKernel::cl_mask_code = "  \n\
struct Dims                 \n\
{                           \n\
  int frameWidth;           \n\
  int frameHeight;          \n\
  float snrThresh;          \n\
  int disableRangeMasking;  \n\
  float maxRangeThresh;     \n\
  int pixelMaskStartX;      \n\
  int pixelMaskStartY;      \n\
  int pixelMaskStepX;       \n\
  int pixelMaskStepY;       \n\
  int pixelMaskStride;      \n\
};                          \n\
#define MASKED_BUFFER_MASK_OFFSET(frameSize) " STRINGIFY(MASKED_BUFFER_MASK_OFFSET(frameSize)) "  \n\
#define MASKED_BUFFER_RANGE_OFFSET(frameSize) " STRINGIFY(MASKED_BUFFER_RANGE_OFFSET(frameSize)) "  \n\
#define MASKED_BUFFER_SNR_OFFSET(frameSize) " STRINGIFY(MASKED_BUFFER_SNR_OFFSET(frameSize)) "  \n\
#define MASKED_BUFFER_BACKGROUND_OFFSET(frameSize) " STRINGIFY(MASKED_BUFFER_BACKGROUND_OFFSET(frameSize)) "  \n\
#define MASKED_BUFFER_SIGNAL_OFFSET(frameSize) " STRINGIFY(MASKED_BUFFER_SIGNAL_OFFSET(frameSize)) "  \n\
#define FRAME_BUFFER_SNR_OFFSET(frameSize) " STRINGIFY(FRAME_BUFFER_SNR_OFFSET(frameSize)) "  \n\
#define FRAME_BUFFER_BACKGROUND_OFFSET(frameSize) " STRINGIFY(FRAME_BUFFER_BACKGROUND_OFFSET(frameSize)) "  \n\
#define FRAME_BUFFER_SIGNAL_OFFSET(frameSize) " STRINGIFY(FRAME_BUFFER_SIGNAL_OFFSET(frameSize)) "  \n\
__kernel void cl_mask_kernel(const __global float *ranges,  \n\
                             const __global float *frameBuffer,  \n\
                                   __global float *minMaxMask,  \n\
                                   __global unsigned short *maskBuffer,  \n\
                                   struct Dims dims)    \n\
{  \n\
  int work_dim = (int)get_work_dim(); \n\
  if (work_dim != 1) return; \n\
  int idx = (int)get_global_id(0);  \n\
  int bufferSize = dims.frameWidth*dims.frameHeight;  \n\
  if (idx >= bufferSize) return;  \n\
  unsigned short *rangeOut = maskBuffer + MASKED_BUFFER_RANGE_OFFSET(bufferSize);  \n\
  float frange = 1024.0*ranges[idx];  \n\
  unsigned short range = (unsigned short)round(frange);  \n\
  if (0 != dims.disableRangeMasking) {  \n\
    rangeOut[idx] = range;  \n\
  }  \n\
  int rangeX = idx % dims.frameWidth;  \n\
  int rangeY = idx / dims.frameWidth;  \n\
  int pixelMaskX = dims.pixelMaskStartX + rangeX*dims.pixelMaskStepX;  \n\
  int pixelMaskY = dims.pixelMaskStartY + rangeY*dims.pixelMaskStepY;  \n\
  int pixelMaskIdx = pixelMaskX + dims.pixelMaskStride * pixelMaskY;  \n\
  unsigned short *pixelMasks = maskBuffer + MASKED_BUFFER_MASK_OFFSET(bufferSize);  \n\
  const float *snrBuffer = frameBuffer + FRAME_BUFFER_SNR_OFFSET(bufferSize);  \n\
  float snr = snrBuffer[idx];  \n\
  if (pixelMasks[pixelMaskIdx] == 0) range = 0;  \n\
  if (minMaxMask[idx] > 0.5F) range = 0;  \n\
  if (snr < 2*dims.snrThresh) range = 0;  \n\
  if (frange > dims.maxRangeThresh) range = 0;  \n\
  rangeOut[idx] = range; \n\
  unsigned short *snrOut = maskBuffer + MASKED_BUFFER_SNR_OFFSET(bufferSize);  \n\
  snrOut[idx] = (unsigned short)(snr/2.0F);  \n\
  const float *backgroundBuffer = frameBuffer + FRAME_BUFFER_BACKGROUND_OFFSET(bufferSize);  \n\
  unsigned short *backgroundOut = maskBuffer + MASKED_BUFFER_BACKGROUND_OFFSET(bufferSize);  \n\
  float avgBg = backgroundBuffer[idx];  \n\
  backgroundOut[idx] = avgBg > 65535.0F ? 0xffff : (unsigned short)(round(avgBg));  \n\
  const float *signalBuffer = frameBuffer + FRAME_BUFFER_SIGNAL_OFFSET(bufferSize);  \n\
  float avgSignal = round(0.5F*signalBuffer[idx]);  \n\
  unsigned short * signalOut = maskBuffer + MASKED_BUFFER_SIGNAL_OFFSET(bufferSize);  \n\
  signalOut[idx] = avgSignal > 65535.0F ? 0xffff : (unsigned short)(avgSignal);  \n\
}";

const char *OpenCLMaskKernel::cl_mask_name = "cl_mask_kernel";

OpenCLMaskKernel::OpenCLMaskKernel(OpenCLKernels &kernels) : 
  _openCLKernel(kernels.getKernel(cl_mask_name, cl_mask_code)) {}

void OpenCLMaskKernel::enqueue(RtdVec &dRanges, 
               RtdVec &dFrameBuffer, 
               RtdVec &minMaxMask, 
               RtdSVec &dMaskBuffer, 
               std::vector<uint32_t> size,
               float snrThresh, bool disableRangeMasking, float maxRangeThresh, 
               std::vector<uint16_t> fovStart, 
               std::vector<uint16_t> fovStep, 
               std::vector<uint16_t> fovSize)
{
  Dims dims {
    (int)size[1], (int)size[0],
    snrThresh,
    (int)disableRangeMasking,
    1024.0F*maxRangeThresh,
    (int)fovStart[1], (int)fovStart[0],
    (int)fovStep[1], (int)fovStep[0],
    (int)fovSize[1]
  };

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void*)(&dRanges.vec));
  RtdVec::errorCheck(res, "OpenCLMaskKernel::enqueue() - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void*)(&dFrameBuffer.vec));
  RtdVec::errorCheck(res, "OpenCLMaskKernel::enqueue() - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_mem), (void*)(&minMaxMask.vec));
  RtdVec::errorCheck(res, "OpenCLMaskKernel::enqueue() - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(cl_mem), (void*)(&dMaskBuffer.vec));
  RtdVec::errorCheck(res, "OpenCLMaskKernel::enqueue() - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(Dims), (void*)(&dims));
  RtdVec::errorCheck(res, "OpenCLMaskKernel::enqueue() - clSetKernelArg 4");

  
  cl_uint work_dim = 1;
  size_t local_work_size[1] = {32};
  size_t global_work_size[1] = {(size_t)LumoUtil::roundToMultiple(size[0]*size[1], local_work_size[0])};

  cl_event event;
  res = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), work_dim, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(res, "OpenCLMaskKernel::enqueue - clEnqueueNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLMaskKernel")->add(event);



}