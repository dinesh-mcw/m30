#pragma once

#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "OpenCLKernels.h"
#include <vector>

// This is a "transpose raw" function, which transposes an image that
// consists of 3-element float raw pixels.
class OpenCLTransposeRawKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_transpose_raw_code;
  static const char *cl_transpose_raw_function_name;

public:
  // Size: the number of raw pixels, e.g. {240,320}, even though there are 960 floats in each row.
  OpenCLTransposeRawKernel(OpenCLKernels &kernels);
  void enqueue(const RtdVec &frameBuffer, RtdVec &out, std::vector<uint32_t> size, uint32_t bufferOffset);
};