#include "OpenCLProfile.h"
#include "LumoUtil.h"

OpenCLProfile::OpenCLProfile(const std::string tag) : _profileTag(tag) {}

void OpenCLProfile::add(cl_event event)
{
#ifdef ENABLE_OPENCL_KERNEL_PROFILING
  auto mutex = std::lock_guard(_mutex);
  cl_int res = clSetEventCallback(event, CL_COMPLETE, &completed, (void *)this);
  _events.push_back(event);
  _totalNumberOfStartedEvents++;
#endif
}

void CL_CALLBACK OpenCLProfile::completed(cl_event event, cl_int status, void *user_data)
{
  auto profile = (OpenCLProfile *)user_data;
  auto mutex = std::lock_guard(profile->_mutex);
  for (auto it = profile->_events.begin(); it != profile->_events.end(); it++)
  {
    if (event == *it)
    {
      cl_ulong start_time, end_time;
      clGetEventProfilingInfo(event, CL_PROFILING_COMMAND_START, sizeof(cl_ulong), &start_time, nullptr);
      clGetEventProfilingInfo(event, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), &end_time, nullptr);

      float_t eventTime = 0.0F;
      if (end_time > start_time) // Yes, this error happens sometimes.
      {
        eventTime = float_t(end_time-start_time)/1.0e3f;
      }
      profile->_totalEventTime += eventTime;
      profile->_totalNumberOfCompletedEvents++;

      profile->_events.erase(it);
      break;
    }
  }
}
