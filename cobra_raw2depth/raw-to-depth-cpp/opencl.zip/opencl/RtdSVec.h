#pragma once
#include "RtdVec.h"
#include <cassert>

#include <CL/cl.h>
#include "GpuProps.h"
#include <cstring>
#include <vector>
#include <cmath>


// TODO: refactor into a template class.
class RtdSVec 
{
public:
  std::shared_ptr<cl_mem> vec_ptr;
  cl_context &context;
  cl_mem &vec;
  cl_int errNum=0;

  RtdSVec(size_t size, GpuProps &props, bool readOnly = false);
  RtdSVec(const std::vector<uint16_t> &in, GpuProps &props, bool readOnly=false);
  void copyout(std::vector<uint16_t> &out, GpuProps &props, uint32_t offset=0);
  void copydown(std::vector<uint16_t> &in, GpuProps &props, uint32_t offset=0);
  ~RtdSVec();
  uint32_t size() const;
};
