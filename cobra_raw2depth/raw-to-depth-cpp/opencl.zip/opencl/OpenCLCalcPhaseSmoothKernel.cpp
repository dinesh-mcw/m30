#include "OpenCLCalcPhaseSmoothKernel.h"
#include "LumoUtil.h"
#include "RtdVec.h"

const char *OpenCLCalcPhaseSmoothKernel::cl_calcPhaseSmooth_code = "\
#define a raw.x  \n\
#define b raw.y  \n\
#define c raw.z  \n\
__kernel void cl_calc_phase_smooth_kernel(const __global float *frameSmoothed, \n\
                                                __global float *phaseSmoothedFrame,   \n\
                                                __global float *frameBuffer,   \n\
                                                __global float *correctedPhaseFrame, \n\
                                                unsigned int outputSize,   \n\
                                                unsigned int frameBufferOffset) { \n\
  __global float *phaseFrame = frameBuffer + frameBufferOffset;  \n\
  int work_dim = (int)get_work_dim();  \n\
  if (work_dim != 1) return;  \n\
  int idx = (int)get_global_id(0); /* output coords. */ \n\
  if (idx >= (int)outputSize) return;  \n\
  const float oneThird = 1.0F/3.0F; \n\
  const float twoThirds = 2.0F/3.0F; \n\
  float frac = 0.0F;  \n\
  //printf(\"cl_calc_phase_smooth_kernel work_dim %d idx %d outputSize %d\\n\", (int)work_dim, (int)get_global_id(0), (int)outputSize);             \n\
  float3 raw = vload3(idx, frameSmoothed); \n\
  if (a <= b && a <= c) \n\
  { \n\
    float tmp = c; \n\
    c = a; \n\
    a = b; \n\
    b = tmp; \n\
    frac = oneThird; \n\
  } \n\
  else if (b <= c && b < a) \n\
  { \n\
    float tmp = a; \n\
    a = c; \n\
    c = b; \n\
    b = tmp; \n\
    frac = twoThirds; \n\
  } \n\
   \n\
  float signal = a + b - 2 * c; \n\
  if (signal <= 0) \n\
    signal = 1; \n\
   \n\
  float part1 = b-c;  \n\
  float iPhaseSmoothed = oneThird*(part1 / signal) + frac; \n\
  float iPhase = phaseFrame[idx]; \n\
   \n\
  phaseSmoothedFrame[idx] = iPhaseSmoothed;  \n\
  float phaseErr = iPhase - iPhaseSmoothed; \n\
  if (phaseErr > 0.5F) { \n\
    iPhase -= 1.0F; \n\
  } \n\
  if (phaseErr < -0.5F) { \n\
    iPhase += 1.0F; \n\
  } \n\
  correctedPhaseFrame[idx] = iPhase; \n\
}";

const char *OpenCLCalcPhaseSmoothKernel::cl_calcPhaseSmooth_name = "cl_calc_phase_smooth_kernel";

OpenCLCalcPhaseSmoothKernel::OpenCLCalcPhaseSmoothKernel(OpenCLKernels &kernels) :
  _openCLKernel(kernels.getKernel(cl_calcPhaseSmooth_name, cl_calcPhaseSmooth_code))
{

}

void OpenCLCalcPhaseSmoothKernel::enqueue(RtdVec &frameSmoothed, 
                                          RtdVec &phaseSmoothedFrame, 
                                          RtdVec &phaseFrame, 
                                          RtdVec &correctedPhaseFrame, 
                                          cl_uint outputSize, 
                                          cl_uint frameBufferOffset)
{

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&frameSmoothed.vec));
  RtdVec::errorCheck(res, "OpenCLCalcPhaseSmoothKernel::enqueue - clSetKernelArg 0");
  
  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&phaseSmoothedFrame.vec));
  RtdVec::errorCheck(res, "OpenCLCalcPhaseSmoothKernel::enqueue - clSetKernelArg 1");
  
  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_mem), (void *)(&phaseFrame.vec));
  RtdVec::errorCheck(res, "OpenCLCalcPhaseSmoothKernel::enqueue - clSetKernelArg 2");
  
  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(cl_mem), (void *)(&correctedPhaseFrame.vec));
  RtdVec::errorCheck(res, "OpenCLCalcPhaseSmoothKernel::enqueue - clSetKernelArg 3");
  
  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(cl_uint), (void *)(&outputSize));
  RtdVec::errorCheck(res, "OpenCLCalcPhaseSmoothKernel::enqueue - clSetKernelArg 4");
  
  res = clSetKernelArg(_openCLKernel->getKernel(), 5, sizeof(cl_uint), (void *)(&frameBufferOffset));
  RtdVec::errorCheck(res, "OpenCLCalcPhaseSmoothKernel::enqueue - clSetKernelArg 5");
  
  cl_uint work_dim = 1;
  size_t local_work_size[1] = {32};
  size_t global_work_size[1] = {(size_t)LumoUtil::roundToMultiple(outputSize, local_work_size[0])};

  cl_event event;
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), work_dim, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLCalcPhaseSmoothKernel::enqueue - clEnqueueNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLCalcPhaseSmoothKernel")->add(event);

}