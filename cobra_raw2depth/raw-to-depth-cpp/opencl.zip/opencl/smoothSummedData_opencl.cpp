
#include "RawToDepthV2_opencl.h"
#include "RawToDepthDsp.h"
#include "LumoUtil.h"
#include <cassert>

void RawToDepthV2_opencl::smoothSummedData(const RtdVec &frameBuffer, RtdVec &roiSmoothed, std::vector<uint32_t> size,
						      uint32_t _rowKernelIdx, uint32_t _columnKernelIdx, uint32_t frqIdx, RawToDepthPlatform &platform)
{
  const auto rowKernelSize = int32_t(RawToDepthDsp::_fKernels[_rowKernelIdx].size());
  const auto columnKernelSize = int32_t(RawToDepthDsp::_fKernels[_columnKernelIdx].size());

  if (rowKernelSize == 5 && columnKernelSize == 7) {
    smoothRaw5x7(frameBuffer, roiSmoothed, size, frqIdx, platform);
    return;
  }

  if (rowKernelSize == 7 && columnKernelSize == 15) {
    smoothRaw7x15(frameBuffer, roiSmoothed, size, frqIdx, platform);
    return;
  }

  if (rowKernelSize == 3 && columnKernelSize == 5) {
    smoothRaw3x5(frameBuffer, roiSmoothed, size, frqIdx, platform);
    return;
  }

  assert(false);
  return;
}

