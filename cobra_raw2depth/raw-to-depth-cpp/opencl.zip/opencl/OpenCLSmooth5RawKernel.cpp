#include "OpenCLSmooth5RawKernel.h"
#include "OpenCLKernels.h"
#include "LumoUtil.h"

const char *OpenCLSmooth5RawKernel::cl_smooth5Raw_code = "\
__kernel void cl_smooth5_raw_kernel(const __global float *in, __global float *out, \n\
                                    const __constant float *k5, unsigned int inputWidth, \n\
                                    unsigned int inputHeight) {  \n\
  int work_dim = (int)get_work_dim();   \n\
  if (work_dim != 2) return;   \n\
  int x = (int)get_global_id(0); /* output coords. */  \n\
  int y = (int)get_global_id(1);   \n\
  int outputWidth = inputWidth;  \n\
  int outputHeight = inputHeight;   \n\
  if (x >= outputWidth || y >= outputHeight) return;   \n\
  int left = x-2;  \n\
  int right = x+2;  \n\
  int offset = left + (int)inputWidth*y;   \n\
  float3 sum;  \n\
  sum = vload3(offset+2, in);  \n\
  if (left < 0 || right >= inputWidth) { vstore3(sum, offset+2, out); return; }  \n\
  sum *= k5[2];   \n\
  sum += vload3(offset, in) * k5[0];  \n\
  sum += vload3(offset+1, in) * k5[1];   \n\
  sum += vload3(offset+3, in) * k5[3];   \n\
  sum += vload3(offset+4, in) * k5[4];   \n\
  vstore3(sum, offset+2, out);   \n\
} ";
const char *OpenCLSmooth5RawKernel::cl_smooth5Raw_name = "cl_smooth5_raw_kernel";

OpenCLSmooth5RawKernel::OpenCLSmooth5RawKernel(OpenCLKernels &kernels) : 
  _openCLKernel(kernels.getKernel(cl_smooth5Raw_name, cl_smooth5Raw_code))
{
}


void OpenCLSmooth5RawKernel::enqueue(RtdVec &in, RtdVec &out, RtdVec &k5, std::vector<uint32_t> size)
{
  auto inputWidth = size[1];
  auto inputHeight = size[0];

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&in.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth5RawKernel::enqueue() - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&out.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth5RawKernel::enqueue() - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_mem), (void *)(&k5.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth5RawKernel::enqueue() - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(unsigned int), (void *)(&inputWidth));
  RtdVec::errorCheck(res, "OpenCLSmooth5RawKernel::enqueue() - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(unsigned int), (void *)(&inputHeight));
  RtdVec::errorCheck(res, "OpenCLSmooth5RawKernel::enqueue() - clSetKernelArg 4");

  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8, 4};
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(inputWidth, local_work_size[0]),
                                LumoUtil::roundToMultiple(inputHeight, local_work_size[1])};

  cl_event event;
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), work_dim, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLSmooth5RawKernel::enqueue - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLSmooth5RawKernel")->add(event);


}
