#pragma once

#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "OpenCLKernels.h"
#include <vector>

// Fixed-size one-dimensional 5-point smoothing function.
class OpenCLSmooth5RawKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_smooth5Raw_code;
  static const char *cl_smooth5Raw_name;

public:
  OpenCLSmooth5RawKernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &in, RtdVec &out, RtdVec &k5, std::vector<uint32_t> size);
};