
#include "RawToDepthV2_opencl.h"
#include "RawToDepthDsp.h"
#include "RawToDepthPlatform.h"
#include "ScopedVec.h"
#include "OpenCLTransposeRawKernel.h"
#include "OpenCLSmooth5RawKernel.h"
#include "OpenCLSmooth3RawKernel.h"
#include "RtdMetadata.h"
#include <cassert>

void RawToDepthV2_opencl::smoothRaw3x5(const RtdVec &dFrameBuffer, RtdVec &dFrameBufferSmoothed, std::vector<uint32_t> frameSize, uint32_t frqIdx, RawToDepthPlatform &platform)
{
  const auto &k3 = RawToDepthDsp::_fKernels[1];
  const auto &k5 = RawToDepthDsp::_fKernels[2];

  uint32_t paddedBufferSize = frameSize[0] * 3 * frameSize[1];
  { // scope for local variables.
    VEC_RO(dK3, k3, platform.getVecs());
    VEC_RO(dK5, k5, platform.getVecs());
    VEC(da, paddedBufferSize, platform.getVecs());
    VEC(db, paddedBufferSize, platform.getVecs()); 

    auto transposeKernel = OpenCLTransposeRawKernel(platform.getKernels());
    auto smooth3Kernel = OpenCLSmooth3RawKernel(platform.getKernels());
    auto smooth5Kernel = OpenCLSmooth5RawKernel(platform.getKernels());

    uint32_t bufferOffset = platform.getStaticBuffers().getOffsetToRawBuffer(frqIdx);
        
    transposeKernel.enqueue(dFrameBuffer, db, {frameSize[0], frameSize[1]}, bufferOffset);
    smooth5Kernel.enqueue(db, da, dK5, {frameSize[1], frameSize[0]});
    transposeKernel.enqueue(da, db, {frameSize[1], frameSize[0]}, 0); 
    smooth3Kernel.enqueue(db, dFrameBufferSmoothed, dK3, {frameSize[0], frameSize[1]});
  }
}
