#include "GpuProps.h"
#include "LumoLogger.h"
#include "RtdVec.h"

static void printComputeCapabilities() {
  cl_uint platformCount;
  cl_platform_id platformIds[1];
  clGetPlatformIDs(1, platformIds, &platformCount);

  if (platformCount == 0) 
  {
    LumoLogDebug("OpenCL found no platforms");
    return;
  }
  LumoLogDebug("OpenCL compute capabilities: ------------------");
  LumoLogDebug("Platform Count: %d. Platform ID %lx", platformCount, (unsigned long)platformIds[0]);

  char profile[32];
  size_t  profile_len;
  clGetPlatformInfo(platformIds[0], CL_PLATFORM_PROFILE, 32, profile, &profile_len);
  LumoLogDebug("Profile %s", profile);

  char version[32];
  clGetPlatformInfo(platformIds[0], CL_PLATFORM_VERSION, 32, version, &profile_len);
  LumoLogDebug("Version %s", version);

  char vendor[32];
  clGetPlatformInfo(platformIds[0], CL_PLATFORM_VENDOR, 32, vendor, &profile_len);
  LumoLogDebug("Vendor %s", vendor);

  char platformName[32];
  clGetPlatformInfo(platformIds[0], CL_PLATFORM_NAME, 32, platformName, &profile_len);
  LumoLogDebug("Name %s", platformName);

  char extensions[2048];
  clGetPlatformInfo(platformIds[0], CL_PLATFORM_EXTENSIONS, 2048, extensions, &profile_len);
  LumoLogDebug("Platform extensions %s\n", extensions);

  cl_device_id deviceIds[10];
  cl_uint numDevices;
  clGetDeviceIDs(platformIds[0], CL_DEVICE_TYPE_GPU, CL_DEVICE_TYPE_ALL, deviceIds, &numDevices);
  LumoLogDebug("Number of devices is %u", numDevices);

  size_t len;
  char deviceName[2048];
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_NAME, 2048, &deviceName, &len);
  char devVendor[2048];
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_VENDOR, 2048, &devVendor, &len);
  char devDriver[2048];
  clGetDeviceInfo(deviceIds[0], CL_DRIVER_VERSION, 2048, &devDriver, &len);
  char devVersion[2048];
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_VERSION, 2048, &devVersion, &len);
  char devType[2048];
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_TYPE, 2048, &devType, &len);


  LumoLogDebug("Device Vendor %s. Name %s. Driver version %s. Device version %s. Device Type %s", devVendor, deviceName, devDriver, devVersion, devType);

  char devExtensions[2048];
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_EXTENSIONS, 2048, &devExtensions, &len);
  LumoLogDebug("Device extensions %s.", devExtensions);

  cl_ulong devGlobalMemSize;
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(cl_ulong), &devGlobalMemSize, &len);
  cl_ulong devLocalMemSize;
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_LOCAL_MEM_SIZE, sizeof(cl_ulong), &devLocalMemSize, &len);
  cl_ulong devMaxAllocSize;
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_MAX_MEM_ALLOC_SIZE, sizeof(cl_ulong), &devMaxAllocSize, &len);
  LumoLogDebug("Device global mem size %lu MB. Device local mem size %lu KB. Max mem alloc size %lu MB", devGlobalMemSize/(1024*1024), devLocalMemSize/1024, devMaxAllocSize/(1024*1024));

  cl_uint maxComputeUnits;
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(cl_uint), &maxComputeUnits, &len);
  size_t maxWorkGroupSize;
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_MAX_WORK_GROUP_SIZE, sizeof(size_t), &maxWorkGroupSize, &len);
  LumoLogDebug("Max number of compute units %u. Max work group %d", maxComputeUnits, maxWorkGroupSize);

  cl_uint maxWorkItemDimensions;
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS, sizeof(cl_uint), &maxWorkItemDimensions, &len);
  LumoLogDebug("Max work item dims: %d", maxWorkItemDimensions);

  if (maxWorkItemDimensions >= 3) 
  {
    size_t maxWorkItemSizes[3];
    clGetDeviceInfo(deviceIds[0], CL_DEVICE_MAX_WORK_ITEM_SIZES, 3*sizeof(size_t), &maxWorkItemSizes, &len);
    LumoLogDebug("Max work item sizes %d,%d,%d", maxWorkItemSizes[0], maxWorkItemSizes[1], maxWorkItemSizes[2]);
  }


  cl_uint vectorWidthFloat;
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT, sizeof(cl_uint), &vectorWidthFloat, &len);
  LumoLogDebug("Vector width float %u", vectorWidthFloat);

  cl_bool imageSupport;
  clGetDeviceInfo(deviceIds[0], CL_DEVICE_IMAGE_SUPPORT, sizeof(cl_bool), &imageSupport, &len);
  LumoLogDebug("Device %s Image Support", imageSupport ? "includes" : "does not include");

  if (imageSupport) 
  {
    size_t maxWidth2d, maxHeight2d, maxWidth3d, maxHeight3d, maxDepth3d;
    clGetDeviceInfo(deviceIds[0], CL_DEVICE_IMAGE2D_MAX_WIDTH, sizeof(size_t),  &maxWidth2d, &len);
    clGetDeviceInfo(deviceIds[0], CL_DEVICE_IMAGE2D_MAX_HEIGHT, sizeof(size_t), &maxHeight2d, &len);
    clGetDeviceInfo(deviceIds[0], CL_DEVICE_IMAGE3D_MAX_WIDTH, sizeof(size_t),  &maxWidth3d, &len);
    clGetDeviceInfo(deviceIds[0], CL_DEVICE_IMAGE3D_MAX_HEIGHT, sizeof(size_t), &maxHeight3d, &len);
    clGetDeviceInfo(deviceIds[0], CL_DEVICE_IMAGE3D_MAX_DEPTH, sizeof(size_t),  &maxDepth3d, &len);
    LumoLogDebug("2D max image size %dx%d. 3D max image size %dx%dx%d", maxHeight2d, maxWidth2d, maxHeight3d, maxWidth3d, maxDepth3d);
  }

  LumoLogDebug("Profiling timer resolution is %d nanoseconds", CL_DEVICE_PROFILING_TIMER_RESOLUTION);

  LumoLogDebug("-----------------------------------------------------------\n");

}


// Assumes we're building for single-gpu system.
GpuProps::GpuProps()
{
  printComputeCapabilities();
  
  cl_uint platformCount;
  cl_platform_id platformIds[10];
  clGetPlatformIDs(10, platformIds, &platformCount);

  if (platformCount < 1) 
  {
    LumoLogErr("Found no GPU platforms in current system. Exiting.");
    exit(-1);
  }

  cl_device_id deviceIds[10];
  cl_uint numDevices;
  clGetDeviceIDs(platformIds[0], CL_DEVICE_TYPE_GPU, CL_DEVICE_TYPE_ALL, deviceIds, &numDevices);

  if (numDevices < 1) 
  {
    LumoLogErr("Found no GPU devices on platform 0. Exiting.");
    exit(-1);
  }

  cl_context_properties properties[3] = {CL_CONTEXT_PLATFORM, (cl_context_properties)(platformIds[0]), 0};
  cl_int errorcode_ret;
  openclContext = clCreateContext(properties, numDevices, &deviceIds[0], nullptr, nullptr, &errorcode_ret);
  deviceId = deviceIds[0];
  cl_command_queue_properties commandQueueProperties = CL_QUEUE_PROFILING_ENABLE;
  commandQueue = clCreateCommandQueue(openclContext, deviceId, commandQueueProperties, &errorcode_ret);

  if (errorcode_ret != CL_SUCCESS)
  {
    LumoLogErr("Context creation return with error %l", errorcode_ret);
    exit(-1);
  }

}

void GpuProps::wait() 
{
  auto clRes = clFinish(commandQueue);
  RtdVec::errorCheck(clRes, "RawToDepthPlatform::wait() - clFinish()");
}