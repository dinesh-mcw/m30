#include "RtdVecs.h"
#include <CL/cl.h>
#include <cassert>

RtdVecs::RtdVecs(GpuProps &gpuProps) :
  _props(gpuProps)
{
  
}

uint32_t RtdVecs::totalBytes()
{
  uint32_t total = 0;
  for (auto idx=0; idx<_vecs.size(); idx++)
    total += sizeof(float_t)*_sizes[idx];
  return total;
}

void RtdVecs::clear()
{
  for (auto idx=0; idx<_vecs.size(); idx++)
  {
    clReleaseMemObject(_vecs[idx]->vec);
  }
  _vecs.clear();
  _sizes.clear();
  _inUse.clear();
  _readonly.clear();
}

std::shared_ptr<RtdVec> RtdVecs::get(uint32_t size, bool readonly)
{
  assert(_vecs.size() == _inUse.size());
  assert(_vecs.size() == _sizes.size());

  for (auto idx=0; idx<_vecs.size(); idx++)
  {
    if (!_inUse[idx] && (readonly==_readonly[idx]) && (_sizes[idx] == size))
    {
      _inUse[idx] = true;
      return _vecs[idx];
    }
  }
  _vecs.push_back(std::make_shared<RtdVec>(size, _props, readonly));
  _inUse.push_back(true);
  _sizes.push_back(size);
  _readonly.push_back(readonly);

  return _vecs.back();
}

void RtdVecs::release(std::shared_ptr<RtdVec> in)
{
  for (auto idx=0; idx<_vecs.size(); idx++)
  {
    if (in == _vecs[idx]) // compares pointer values.
    {
      assert(_inUse[idx]);
      _inUse[idx] = false;
    }
  }
}


std::shared_ptr<RtdVec> RtdVecs::get(const std::vector<float_t> &in, bool readonly)
{
  auto a = get(in.size(), readonly);
  cl_bool blocking_write = false;
  cl_event event;
  cl_int res = clEnqueueWriteBuffer(_props.commandQueue, a->vec, blocking_write, 0, sizeof(float_t)*in.size(), (void*)(in.data()), 0, nullptr, &event);
  RtdVec::errorCheck(res, "RtdVecs::get - clEnqueueWriteBuffer");
  _props.profiler.get("CopyDown")->add(event);
  return a;
}