#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "LumoLogger.h"
#include "LumoTimers.h"

// The string functionName must match the function name defined in kernelCode.
OpenCLKernel::OpenCLKernel(GpuProps &gpuProps, std::string functionName, std::string kernelCode) : 
  _gpuProps(gpuProps)
{
  const cl_uint count = 1;
  const char *strings[1] = {kernelCode.c_str()};
  const size_t lengths[1] = {kernelCode.size()};
  cl_int errcode_ret;
  _program = clCreateProgramWithSource(_gpuProps.openclContext, count, strings, lengths, &errcode_ret);
  RtdVec::errorCheck(errcode_ret, "OpenCLKernel::OpenCLKernel - clCreateProgramWithSource");

  cl_uint num_devices = 1;
  const cl_device_id device_list[1] = {_gpuProps.deviceId};
  errcode_ret = clBuildProgram(_program, 1, device_list, "", nullptr, nullptr);

  {
    cl_build_status build_status;
    cl_int errcode = clGetProgramBuildInfo(_program, _gpuProps.deviceId, CL_PROGRAM_BUILD_STATUS, sizeof(cl_build_status), &build_status, nullptr);
    std::string msg;
    if (build_status == CL_BUILD_NONE) msg = "CL_BUILD_NONE";
    if (build_status == CL_BUILD_ERROR) msg = "CL_BUILD_ERROR";
    if (build_status == CL_BUILD_SUCCESS) msg = "CL_BUILD_SUCCESS";
    if (build_status == CL_BUILD_IN_PROGRESS) msg = "CL_BUILD_IN_PROGRESS";
  }

  if (CL_SUCCESS != errcode_ret) 
  {
    size_t param_value_size_ret;
    cl_int infoErr = clGetProgramBuildInfo(_program, _gpuProps.deviceId, CL_PROGRAM_BUILD_LOG, 0, nullptr, &param_value_size_ret);
    std::vector<char> compilerLog(param_value_size_ret);
    infoErr = clGetProgramBuildInfo(_program, _gpuProps.deviceId, CL_PROGRAM_BUILD_LOG, compilerLog.size()*sizeof(char), (void*)(compilerLog.data()), &param_value_size_ret);
    RtdVec::errorCheck(infoErr, "OpenCLKernel ctor - clGetProgramBuildInfo");
    LumoLogDebug("Compiler Log:%s", compilerLog.data());
  }
  RtdVec::errorCheck(errcode_ret, "OpenCVLKernel::OpenCLKernel - clBuildProgram.");

  _kernel = clCreateKernel(_program, functionName.c_str(), &errcode_ret);
  RtdVec::errorCheck(errcode_ret, "OpenCLKernel::OpenCLKernel - clCreateKernel");
}
