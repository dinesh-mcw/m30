#include "../RtdVec.h"
#include "LumoLogger.h"

static std::string errNum2Str(cl_int errNum)
{
  switch (errNum)
  {
  case CL_BUILD_PROGRAM_FAILURE:
    return "Build Program Failure";
  case CL_INVALID_OPERATION:
    return "Invalid Operation";
  case CL_COMPILER_NOT_AVAILABLE:
    return "Compiler Not Available";
  case CL_INVALID_BUILD_OPTIONS:
    return "Invalid Build Options";
  case CL_INVALID_ARG_INDEX:
    return "Invalid Argument Index";
  case CL_INVALID_ARG_SIZE:
    return "Invalid argument size";
  case CL_INVALID_DEVICE:
    return "Invalid Device";
  case CL_INVALID_PROGRAM:
    return "Invalid Program.";
  case CL_INVALID_PROGRAM_EXECUTABLE:
    return "Invalid Program Executable";
  case CL_INVALID_KERNEL:
    return "Invalid Kernel";
  case CL_INVALID_KERNEL_ARGS:
    return "Invalid Kernel Args";
  case CL_INVALID_KERNEL_NAME:
    return "Invalid Kernel Name";
  case CL_INVALID_KERNEL_DEFINITION:
    return "Invalid Kernel Definition";
  case CL_INVALID_WORK_DIMENSION:
    return "Invalid Work Dimension";
  case CL_INVALID_WORK_GROUP_SIZE:
    return "Invalid Work Group Size";
  case CL_INVALID_WORK_ITEM_SIZE:
    return "Invalid Work Item Size";
  case CL_INVALID_COMMAND_QUEUE:
    return "Invalid command queue";
  case CL_INVALID_CONTEXT:
    return "Invalid context";
  case CL_INVALID_MEM_OBJECT:
    return "Invalid mem object";
  case CL_INVALID_VALUE:
    return "CL_INVALID_VALUE: Invalid flags, or the region being read or written specified by origin and region is out of bounds or if ptr is a NULL value.";
  case CL_INVALID_EVENT_WAIT_LIST:
    return "Invalid wait list";
  case CL_INVALID_EVENT:
   return "Invalid Event";
  case CL_INVALID_BUFFER_SIZE:
    return "Invalid buffer size.";
  case CL_MISALIGNED_SUB_BUFFER_OFFSET:
    return "misaligend sub buffer offset.";
  case CL_MEM_OBJECT_ALLOCATION_FAILURE:
    return "CL_MEM_OBJECT_ALLOCATION_FAILURE: failure to allocate memory for data store associated with buffer.";
  case CL_OUT_OF_RESOURCES:
    return "CL_OUT_OF_RESOURCES : failure to allocate resources required by the OpenCL implementation on the device.";
  case CL_OUT_OF_HOST_MEMORY:
    return "Out of host memory";

  case CL_INVALID_HOST_PTR:
    return "Invalid host pointer.";
  default:
    return "OpenCL Error";
  }
}

void RtdVec::copyout(std::vector<float> &out, GpuProps &props, uint32_t offset)
{
  cl_bool blocking_read = true;
  cl_event event;
  assert(out.size() + offset <= size());
  auto res = clEnqueueReadBuffer(props.commandQueue, vec, blocking_read, (size_t)offset * sizeof(float_t), out.size() * sizeof(float_t), (void *)(out.data()), 0, nullptr, &event);
  RtdVec::errorCheck(res, "RtdVec::copyout - clEnqueueReadBuffer");
  props.profiler.get("copyout")->add(event);
}

void RtdVec::copydown(std::vector<float> &in, GpuProps &props, uint32_t offset)
{
  cl_bool blocking_write = true;
  cl_event event;
  assert(in.size() + offset <= size());
  auto res = clEnqueueWriteBuffer(props.commandQueue, vec, blocking_write, sizeof(float_t)*(size_t)offset, in.size()*sizeof(float_t), (void*)(in.data()), 0, nullptr, &event);
  RtdVec::errorCheck(res, "RtdVec::copydown - clEnqueueWriteBuffer");
  props.profiler.get("copydown")->add(event);
}

void RtdVec::errorCheck(cl_int errNum, std::string note)
{
  if (errNum != CL_SUCCESS)
    LumoLogErr("%s failed with (%d) %s", note.c_str(), errNum, errNum2Str(errNum).c_str());
  assert(errNum == CL_SUCCESS);
}

uint32_t RtdVec::size() const
{
  cl_int errNum;
  size_t sizeBytes = 0;
  errNum = clGetMemObjectInfo(vec, CL_MEM_SIZE, sizeof(size_t), &sizeBytes, nullptr);
  RtdVec::errorCheck(errNum, "Error getting size of RtdVec");
  return sizeBytes / sizeof(float_t);
}

RtdVec::RtdVec(size_t size, GpuProps &props, bool readonly) : 
  vec_ptr(std::make_shared<cl_mem>(clCreateBuffer(props.openclContext, (readonly ? CL_MEM_READ_ONLY : CL_MEM_READ_WRITE), sizeof(float_t) * size, NULL, &errNum))),
  context(props.openclContext),
  vec(*vec_ptr)
{
  RtdVec::errorCheck(errNum, "RtdVec ctor - clCreateBuffer");
}

RtdVec::RtdVec(const std::vector<float_t> &in, GpuProps &props, bool readOnly) : 
  vec_ptr(std::make_shared<cl_mem>(clCreateBuffer(props.openclContext, (readOnly ? CL_MEM_READ_ONLY : CL_MEM_READ_WRITE), sizeof(float_t) * in.size(), nullptr, &errNum))),
  context(props.openclContext),
  vec(*vec_ptr)
{
  RtdVec::errorCheck(errNum, "RtdVec ctor with copy");
  cl_bool blocking_write = false;
  cl_event event;
  errNum = clEnqueueWriteBuffer(props.commandQueue, vec, blocking_write, 0, sizeof(float) * in.size(), (void *)(in.data()), 0, nullptr, &event);
  RtdVec::errorCheck(errNum, "RtdVec ctor - clEnqueueWriteBuffer");
  props.profiler.get("copydown")->add(event);
}

RtdVec::~RtdVec()
{
  if (vec_ptr.use_count() > 1) 
    return;
  cl_int res = 0;
  if (vec_ptr)
    res = clReleaseMemObject(*vec_ptr);
  RtdVec::errorCheck(res, "RtdVec::~RtdVec - clReleaseMemObject");
}