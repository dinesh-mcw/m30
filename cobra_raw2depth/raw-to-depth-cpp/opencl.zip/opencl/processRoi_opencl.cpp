#include "RawToDepthV2_opencl.h"
#include "LumoUtil.h"
#include "ScopedVec.h"
#include "OpenCLBin1x1Kernel.h"
#include "OpenCLProcessRoiKernel.h"
#include <LumoTimers.h>
#include <cassert>

// Called on 40x640 3-element raw ROI data points at a rate of 910 Hz.
// This routine is called 91 times per frame. Then
// processWholeFrame() is called once per frame.
//
void RawToDepthV2_opencl::processRoi(uint16_t *roi, uint32_t numBytes)
{
  if (!validateMetadata(roi, numBytes)) return;

  _timers.start("processRoi() OpenCL - hdr and copydown", TIMERS_UPDATE_EVERY);
  // On the Cortex A35, simple cast and copy takes ~200us/ROI or >18ms per frame.
  _hdr.submit(roi, numBytes / sizeof(uint16_t), _fovIdx, !_firstRoiReceived, 1);
  auto md = _hdr.getMetadata(); // metadata matches the roiVector.
  std::vector<float> &cpuRoi = _hdr.getRoi(); 

  if (!_firstRoiReceived && !_hdr.skip()) md.printMetadata();
  _firstRoiReceived = true;

  auto dRoi = _platform.getStaticBuffers().getRoiBuffer(cpuRoi); // blocking write.

  if (_hdr.skip()) return; // skipThis ROI
  if (md.getFirstRoi(_fovIdx)) reset(_hdr.getMetadataVector().data(), ROI_NUM_COLUMNS * NUM_GPIXEL_PHASES * sizeof(uint16_t)); // Assume vector pool and VEC/ScopedVecs are invalidated here.
  if (!saveTimestamp(md)) return;
  
  // These are the sizes of the roiFnSummed, binned, ROI buffers.
  uint16_t roiHeight = md.getRoiNumRows() / md.getBinningY(_fovIdx);
  uint32_t roiWidth = ROI_NUM_COLUMNS / md.getBinningX(_fovIdx);
  uint32_t roiCol = ROI_START_COLUMN / (uint32_t)md.getBinningX(_fovIdx);
  // The getRoiStartRow() is the row on the sensor that the ROI pixels begin.
  // The getFovStartRow() is the row on the sensor that this FOV starts.
  // The output buffer is only the size of the FOV, so this start row needs to be adjusted so that the start
  //   of the FOV starts at the top of the buffer.
  uint32_t roiRow = (md.getRoiStartRow() - md.getFovStartRow(_fovIdx)) / (uint32_t)md.getBinningY(_fovIdx);

  auto dFrameBuffer = _platform.getStaticBuffers().getFrameBuffer();

  uint32_t imageWidth=md.getFullImageWidth(_fovIdx), imageHeight=md.getFullImageHeight(_fovIdx);
  _timers.stop("processRoi() OpenCL - hdr and copydown");

  if (false)
  {
    // OpenCL Kernel enqueueing passed to another thread.
    // Motivation: processRoi() is called at 910 Hz, the overhead for CPU-side OpenCL calls is ~150 us.
    // This threading code requires a redesign. The OpenCL kernel done callback has no guarantees on latency. Gives good benchmarks on Variscite VAR-SOM-MX8X, but not on Intel/NVidia laptop.
    auto t = LumoTimers::ScopedTimer(_timers, "processRoi() -- processRoiThread.set()", TIMERS_UPDATE_EVERY);
    _processRoiThread.set(dRoi, dFrameBuffer, md.getBinningY(_fovIdx), {md.getRoiNumRows(), ROI_NUM_COLUMNS}, roiRow, roiCol, imageWidth, imageHeight, md.getBinningY(_fovIdx) * md.getBinningX(_fovIdx) );
  }
  else
  {
    auto t = LumoTimers::ScopedTimer(_timers, "processRoi() -- processRoiKernel", TIMERS_UPDATE_EVERY);
    assert(md.getBinningX(_fovIdx) == md.getBinningY(_fovIdx));
    auto k = OpenCLProcessRoiKernel(_platform.getKernels());
    k.enqueue(dRoi, dFrameBuffer, 
              md.getBinningY(_fovIdx),               // binning
              {md.getRoiNumRows(), ROI_NUM_COLUMNS}, // roiSize
              roiRow, roiCol,
              imageWidth, imageHeight,
              md.getBinningY(_fovIdx) * md.getBinningX(_fovIdx) );
  }


}
