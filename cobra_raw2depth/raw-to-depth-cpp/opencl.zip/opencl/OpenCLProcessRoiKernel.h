#pragma once

#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "OpenCLKernels.h"
#include <vector>

// SuperKernel to process all per-ROI functions in sequence.
class OpenCLProcessRoiKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_process_roi_code;
  static const char *cl_process_roi_name;
  cl_event _event;

public:
  OpenCLProcessRoiKernel(OpenCLKernels &kernels);
  void enqueue(std::shared_ptr<RtdVec> rawRoi,
               std::shared_ptr<RtdVec>frameBuffer, 
               cl_int BINNING,  
               std::vector<uint32_t> roiSize, 
               cl_int roiRow, cl_int roiCol,
               cl_int imageWidth, cl_int imageHeight,
               uint32_t numberOfSummedValues);
  
  cl_event &getEvent() { return _event; }
};