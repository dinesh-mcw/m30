#include "ScopedVec.h"

ScopedVec::ScopedVec(uint32_t size, RtdVecs &vecs, bool readonly) :
  _vecs(vecs),
  _vec(vecs.get(size, readonly))
{
}

ScopedVec::ScopedVec(const std::vector<float_t> &in, RtdVecs &vecs, bool readonly) :
  _vecs(vecs),
  _vec(vecs.get(in, readonly))
{
}

ScopedVec::~ScopedVec()
{
  _vecs.release(_vec);
}