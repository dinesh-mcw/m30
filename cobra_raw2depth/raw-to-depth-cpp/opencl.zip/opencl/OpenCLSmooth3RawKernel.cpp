#include "OpenCLSmooth3RawKernel.h"
#include "OpenCLKernels.h"
#include "LumoUtil.h"

const char *OpenCLSmooth3RawKernel::cl_smooth3Raw_code = "\
__kernel void cl_smooth3_raw_kernel(const __global float *in, __global float *out, \n\
                                    const __constant float *k3, unsigned int inputWidth,  \n\
                                    unsigned int inputHeight) {\n\
  int work_dim = (int)get_work_dim(); \n\
  if (work_dim != 2) return; \n\
  int x = (int)get_global_id(0); /* output coords. */\n\
  int y = (int)get_global_id(1); \n\
  int outputWidth = inputWidth;\n\
  int outputHeight = inputHeight; \n\
  if (x >= outputWidth || y >= outputHeight) return; \n\
  int left = x-1;\n\
  int right = x+1;\n\
  int offset = left + (int)inputWidth*y; \n\
  float3 sum;\n\
  sum = vload3(offset+1, in);\n\
  if (left < 0 || right >= inputWidth) { vstore3(sum, offset+1, out); return; }\n\
  sum *= k3[1]; \n\
  sum += vload3(offset, in) * k3[0];\n\
  sum += vload3(offset+2, in) * k3[2]; \n\
  vstore3(sum, offset+1, out); \n\
} ";
const char *OpenCLSmooth3RawKernel::cl_smooth3Raw_name = "cl_smooth3_raw_kernel";

OpenCLSmooth3RawKernel::OpenCLSmooth3RawKernel(OpenCLKernels &kernels) : 
  _openCLKernel(kernels.getKernel(cl_smooth3Raw_name, cl_smooth3Raw_code))
{
}


void OpenCLSmooth3RawKernel::enqueue(RtdVec &in, RtdVec &out, RtdVec &k3, std::vector<uint32_t> size)
{
  auto inputWidth = size[1];
  auto inputHeight = size[0];

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&in.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth3RawKernel::enqueue() - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&out.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth3RawKernel::enqueue() - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_mem), (void *)(&k3.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth3RawKernel::enqueue() - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(unsigned int), (void *)(&inputWidth));
  RtdVec::errorCheck(res, "OpenCLSmooth3RawKernel::enqueue() - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(unsigned int), (void *)(&inputHeight));
  RtdVec::errorCheck(res, "OpenCLSmooth3RawKernel::enqueue() - clSetKernelArg 4");

  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8, 4};
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(inputWidth, local_work_size[0]),
                                LumoUtil::roundToMultiple(inputHeight, local_work_size[1])};

  cl_event event;
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), 2, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLSmooth3RawKernel::enqueue - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLSmooth3RawKernel")->add(event);

}
