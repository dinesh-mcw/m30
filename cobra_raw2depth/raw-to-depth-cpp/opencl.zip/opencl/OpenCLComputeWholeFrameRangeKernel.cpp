
#include "OpenCLComputeWholeFrameRangeKernel.h"
#include "LumoUtil.h"
#include <cassert>

const char *OpenCLComputeWholeFrameRangeKernel::cl_computeWholeFrameRange_code = "\
__kernel void cl_compute_whole_frame_range_kernel(const __global float* fSmoothedPhases0,\n\
                                                  const __global float *fSmoothedPhases1, \n\
                                                  const __global float *fCorrectedPhases0, \n\
                                                  const __global float *fCorrectedPhases1, \n\
                                                        __global float *fRanges, \n\
                                                  const unsigned int bufferLength, \n\
                                                  const float a, \n\
                                                  const float c, \n\
                                                  const float iFInt0, \n\
                                                  const float iFInt1, \n\
                                                        __global float *mFrame) { \n\
  int work_dim = (int)get_work_dim(); \n\
  if (work_dim != 1) return; \n\
  size_t idx = get_global_id(0); //idx is per-4-float \n\
  if ((int)idx >= bufferLength/4) return; \n\
  \n\
  float4 phaseSmoothed0 = vload4(idx, fSmoothedPhases0); \n\
  float4 phaseSmoothed1 = vload4(idx, fSmoothedPhases1); \n\
  \n\
  float4 maskNegatives = (phaseSmoothed1 < phaseSmoothed0) ? 1.0F : 0.0F; \n\
  float4 mRaw1 = iFInt0 * phaseSmoothed1; \n\
  float4 mRaw2 = iFInt1 * phaseSmoothed0; \n\
  float4 mRaw3 = iFInt0 * maskNegatives; \n\
  float4 mRaw_tmp = mRaw1 - mRaw2 + mRaw3; \n\
  \n\
  float4 m = round(mRaw_tmp); \n\
  \n\
  float4 m_out = m + m + maskNegatives; \n\
  vstore4(m_out, idx, mFrame); \n\
  \n\
  float4 phase0 = vload4(idx, fCorrectedPhases0);  \n\
  float4 phase1 = vload4(idx, fCorrectedPhases1); \n\
  float4 b = m + phase1 + maskNegatives; \n\
  float4 d = m + phase0; \n\
  \n\
  float4 range = a*b + c*d; \n\
  //if (range < 0) range = 0; \n\
  range = max(range, (float4)(0.0F,0.0F,0.0F,0.0F)); \n\
  \n\
  vstore4(range, idx, fRanges); \n\
}";

const char *OpenCLComputeWholeFrameRangeKernel::cl_computeWholeFrameRange_name = "cl_compute_whole_frame_range_kernel";

OpenCLComputeWholeFrameRangeKernel::OpenCLComputeWholeFrameRangeKernel(OpenCLKernels &kernels) :
  _openCLKernel(kernels.getKernel(cl_computeWholeFrameRange_name, cl_computeWholeFrameRange_code))
{
}

void OpenCLComputeWholeFrameRangeKernel::enqueue(RtdVec &dSmoothedPhases0,
                                                 RtdVec &dSmoothedPhases1,
                                                 RtdVec &dCorrectedPhases0,
                                                 RtdVec &dCorrectedPhases1,
                                                 RtdVec &dRanges,
                                                 std::vector<float_t> fs,
                                                 std::vector<float_t> fsInt,
                                                 RtdVec &mFrame)
{
  uint32_t outputSize = dSmoothedPhases0.size();
  assert(outputSize % 4 == 0);

  //Precompute a couple of constants.
  const cl_float a = 0.5F * 299792458.0F / (2.0F * fs[1]);
  const cl_float c = 0.5F * 299792458.0F / (2.0F * fs[0]);

  cl_int err;
  err = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&(dSmoothedPhases0.vec))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 0");

  err = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&(dSmoothedPhases1.vec))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 1");

  err = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_mem), (void *)(&(dCorrectedPhases0.vec))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 2");

  err = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(cl_mem), (void *)(&(dCorrectedPhases1.vec))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 3");

  err = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(cl_mem), (void *)(&(dRanges.vec))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 4");

  err = clSetKernelArg(_openCLKernel->getKernel(), 5, sizeof(cl_uint), (void *)(&(outputSize))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 5");

  err = clSetKernelArg(_openCLKernel->getKernel(), 6, sizeof(cl_float), (void *)(&(a))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 6");

  err = clSetKernelArg(_openCLKernel->getKernel(), 7, sizeof(cl_float), (void *)(&(c))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 7");

  err = clSetKernelArg(_openCLKernel->getKernel(), 8, sizeof(cl_float), (void *)(&(fsInt[0]))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 8");

  err = clSetKernelArg(_openCLKernel->getKernel(), 9, sizeof(cl_float), (void *)(&(fsInt[1]))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 9");

  err = clSetKernelArg(_openCLKernel->getKernel(), 10, sizeof(cl_mem), (void *)(&(mFrame.vec))); 
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue() - clSetKernelArg 10");

  //global work size is buffer length/4 to accommodate float4 math.
  cl_uint work_dim = 1;
  size_t local_work_size[1] = {32};
  size_t global_work_size[1] = {(size_t)LumoUtil::roundToMultiple(outputSize/4, local_work_size[0])};

  cl_event event;
  err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), work_dim, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLComputeWholeFrameRangeKernel::enqueue - clEnqueueNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLComputeWholeFrameRangeKernel")->add(event);


}
