#pragma once

#include "RtdVec.h"
#include <vector>
#include <memory>
#include <cstdint>

// A pool to hold allocated OpenCL GPU memory buffers.
class RtdVecs
{
public:
  RtdVecs(GpuProps &gpuProps);
  RtdVecs &operator=(RtdVecs &other);

  // Retrieves a memory buffer that is not in-use, matches the requested size and readonly status.
  std::shared_ptr<RtdVec> get(uint32_t size, bool readonly=false);
  // Retrieves a memory buffer that matches the given size and read-only status, then enqueues
  // a copy operation to move the given vector onto the GPU.
  std::shared_ptr<RtdVec> get(const std::vector<float_t> &in, bool readonly=false);
  void clear(); 
  void release(std::shared_ptr<RtdVec> in);

private:
  GpuProps &_props;
  uint32_t totalBytes();
  std::vector<std::shared_ptr<RtdVec>> _vecs;
  std::vector<bool> _inUse;
  std::vector<bool> _readonly;
  std::vector<uint32_t> _sizes;
};  

