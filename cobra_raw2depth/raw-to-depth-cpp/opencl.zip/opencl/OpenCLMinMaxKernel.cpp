#include "OpenCLMinMaxKernel.h"
#include "LumoUtil.h"


const char *OpenCLMinMaxKernel::cl_minMax_code = "\
#define chk(a) { minVal = fmin(a.x, minVal); minVal = fmin(a.y, minVal); minVal = fmin(a.z, minVal); maxVal = fmax(a.x, maxVal); maxVal = fmax(a.y, maxVal); maxVal = fmax(a.z, maxVal);} \n\
__kernel void cl_min_max_3x3_kernel(const __global float *_in, __global float *out, \n\
                                unsigned int inputWidth, \n\
                                unsigned int inputHeight, \n\
                                float minMaxThresh ) { \n\
  int work_dim = (int)get_work_dim();   \n\
  if (work_dim != 2) return;   \n\
  int x = (int)get_global_id(0);   \n\
  int y = (int)get_global_id(1);   \n\
  if (x >= inputWidth || y >= inputHeight) return;   \n\
  if (x<1 || y<1 || x >= inputWidth-1 || y >= inputHeight-1) { out[x + inputWidth*y] = 0.0F; return; } \n\
  float *in = (float*)(_in + x-1 + inputWidth*(y-1)); \n\
  float minVal = FLT_MAX; \n\
  float maxVal = FLT_MIN; \n\
  float3 a = vload3(0, in); \n\
  chk(a); \n\
  in += inputWidth; \n\
  a = vload3(0, in);\n\
  chk(a); \n\
  in += inputWidth; \n\
  a = vload3(0, in);\n\
  chk(a); \n\
  float outVal = 0.0F; \n\
  if (fabs(maxVal-minVal) > minMaxThresh) outVal = 1.0F; \n\
  out[x + inputWidth*y] = outVal;\n\
  \n\
}";
const char *OpenCLMinMaxKernel::cl_minMax_name = "cl_min_max_3x3_kernel";


OpenCLMinMaxKernel::OpenCLMinMaxKernel(OpenCLKernels &kernels) :
  _openCLKernel(kernels.getKernel(cl_minMax_name, cl_minMax_code)) {}

void OpenCLMinMaxKernel::enqueue(const RtdVec &frame, RtdVec &minMaxMask, std::vector<uint32_t> filterSize, std::vector<uint32_t> frameSize, float_t minMaxThresh)
{
  if (filterSize.size() != 2) // bypass this filter if it is disabled.
  {
    cl_float fillValue = 0.0F; // unmask a pixel by setting this mask value to zero.
    cl_int res;
    cl_event event;
    res = clEnqueueFillBuffer(_openCLKernel->getProps().commandQueue, minMaxMask.vec, &fillValue, sizeof(cl_float), 0, frameSize[0]*frameSize[1]*sizeof(cl_float), 0, nullptr, &event);
    RtdVec::errorCheck(res, "OpenCLMinMaxKernel::enqueue - clEnqueueFillBuffer");
    _openCLKernel->getProps().profiler.get("OpenCLMinMaxKernel")->add(event);
  return;
  }
  // Throw up a warning at runtime if we are doing something other than 2x2 or 4x4 binning.
  assert(filterSize[0] == 3);
  assert(filterSize[1] == 3);

  cl_uint inputWidth = frameSize[1];
  cl_uint inputHeight = frameSize[0];

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&frame.vec));
  RtdVec::errorCheck(res, "OpenCLMinMaxKernel::enqueue - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&minMaxMask.vec));
  RtdVec::errorCheck(res, "OpenCLMinMaxKernel::enqueue - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_uint), (void *)(&inputWidth));
  RtdVec::errorCheck(res, "OpenCLMinMaxKernel::enqueue - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(cl_uint), (void *)(&inputHeight));
  RtdVec::errorCheck(res, "OpenCLMinMaxKernel::enqueue - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(cl_float), (void *)(&minMaxThresh));
  RtdVec::errorCheck(res, "OpenCLMinMaxKernel::enqueue - clSetKernelArg 3");

  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8, 4};
  // The number of raw-triplet pixels processed in the image excludes the padding
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(inputWidth, local_work_size[0]),
                                LumoUtil::roundToMultiple(inputHeight, local_work_size[1])};

  cl_event event;
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), work_dim, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLMinMaxKernel::enqueue - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLMinMaxKernel")->add(event);


}