#pragma once
#include "OpenCLKernels.h"
#include <memory>
#include <RtdVec.h>

// Plus-shaped median filter with fixed 5x7 kernel.
class OpenCLMedianPlus5x7Kernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_median_5x7_code;
  static const char *cl_median_5x7_name;

public:
  OpenCLMedianPlus5x7Kernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &dIn, RtdVec &dOut, std::vector<uint32_t> frameSize, bool performGhostMedian);
};