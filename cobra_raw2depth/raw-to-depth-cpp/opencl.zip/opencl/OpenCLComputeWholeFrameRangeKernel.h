#pragma once

#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "OpenCLKernels.h"
#include <vector>

class OpenCLComputeWholeFrameRangeKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_computeWholeFrameRange_code;
  static const char *cl_computeWholeFrameRange_name;

public:
  OpenCLComputeWholeFrameRangeKernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &dSmoothedPhases,
               RtdVec &dSmoothedPhases1,
               RtdVec &dCorrectedPhases0,
               RtdVec &dCorrectedPhases1,
               RtdVec &dRanges,
               std::vector<float_t> fs,
               std::vector<float_t> fsInt,
               RtdVec &mFrame);
};