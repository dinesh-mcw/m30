#include "ProcessRoiThread.h"
#include <cassert>

ProcessRoiThread::ProcessRoiThread(OpenCLProcessRoiKernel kernel) :
  _kernel(kernel)
{
  _future = std::async(std::launch::async, &run, this);
}

// Note: this implementation appears to be flawed. It doesn't seem as if this HW-to-SW callback has any
// guarantees on latency. A new asynchronous implementation will be required to execute this properly
void CL_CALLBACK ProcessRoiThread::kernelDone(cl_event event, cl_int event_command_exec_status, void *inst)
{
  {
    std::unique_lock<std::mutex> lk{((ProcessRoiThread*)inst)->_mutex};
    ((ProcessRoiThread*)inst)->_kernelRunning = false;
    ((ProcessRoiThread*)inst)->_condition_variable.notify_all();
  }
}

ProcessRoiThread::~ProcessRoiThread()
{
  LumoLogDebug("ProcessRoiThread::~ProcessRoiThread");
  _quitNow = true;
  _dataReady = true;
  _condition_variable.notify_all();
  LumoLogDebug("ProcessRoiThread::~ProcessRoiThread waiting for running thread.");
  _future.wait();
}

void ProcessRoiThread::run(ProcessRoiThread *inst)
{
  while(true)
  {
    std::unique_lock<std::mutex> lk{inst->_mutex};
    if (!inst->_quitNow && !inst->_dataReady)
      inst->_condition_variable.wait(lk, [=]{ return inst->_quitNow || inst->_dataReady;});
    if (inst->_quitNow) 
    {
      return;
    }
    inst->_dataReady = false;
    inst->_kernelRunning = true;
    inst->_kernel.enqueue(inst->_dRoi, inst->_dFrameBuffer, 
            inst->_binningY, // binning
            inst->_roiSize,              // roiSize
            inst->_roiRow, inst->_roiCol,
            inst->_imageWidth, inst->_imageHeight,
            inst->_numberOfSummedValues);
    clSetEventCallback(inst->_kernel.getEvent(), CL_COMPLETE, &kernelDone, inst);
  }
}

void ProcessRoiThread::set(std::shared_ptr<RtdVec> dRoi,
               std::shared_ptr<RtdVec>dFrameBuffer, 
               cl_int binningY,  
               std::vector<uint32_t> roiSize, 
               cl_int roiRow, cl_int roiCol,
               cl_int imageWidth, cl_int imageHeight,
               uint32_t numberOfSummedValues)
{
  {  
    std::unique_lock<std::mutex> lk{_mutex};
    if (_kernelRunning)
      _condition_variable.wait(lk, [=]{return !_kernelRunning; });
    _dRoi = dRoi;
    _dFrameBuffer = dFrameBuffer;
    _binningY = binningY;
    _roiSize = roiSize;
    _roiRow = roiRow;
    _roiCol = roiCol;
    _imageWidth = imageWidth;
    _imageHeight = imageHeight;
    _numberOfSummedValues = numberOfSummedValues;
    _dataReady = true;
    _kernelRunning = true;
    _condition_variable.notify_all();
  }
}

// Wait for the thread to complete.
// Wait for both conditions: kernel has completed, and there's no new data available.
void ProcessRoiThread::wait()
{
  std::unique_lock<std::mutex> lk{_mutex};
  if (_kernelRunning || _dataReady)
    _condition_variable.wait(lk, [=]{ return !_kernelRunning && !_dataReady; });
}