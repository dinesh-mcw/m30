#pragma once

#include "GpuProps.h"
#include <string>
#include <CL/cl.h>

class OpenCLKernel
{
protected:
  GpuProps &_gpuProps;
  cl_program _program;
  cl_kernel _kernel;

public:

  OpenCLKernel(GpuProps &gpuProps, std::string functionName, std::string kernelCode);
  cl_kernel &getKernel() { return _kernel; }
  GpuProps &getProps() { return _gpuProps; }
};