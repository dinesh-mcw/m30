#pragma once

#include "RawToDepthPlatform.h"
#include <cstdint>
#include <memory>

// Pulls a GPU memory buffer from the cache, then releases it when destructed
class ScopedVec
{
public:
  ScopedVec(uint32_t size, RtdVecs &vecs, bool readonly=false);
  ScopedVec(const std::vector<float_t> &in, RtdVecs &vecs, bool readonly=false);
  ~ScopedVec();
  std::shared_ptr<RtdVec> get() { return _vec; }
  
private:
  RtdVecs &_vecs;
  std::shared_ptr<RtdVec> _vec;
};

// Convenience macros for acquiring a GPU memory buffer from the cache, that is released when falling out of scope.
#define VEC(a, b, vecs) auto a##_scoped = ScopedVec(b, vecs); auto &a = *(a##_scoped.get());
// Retrieves a read-only buffer from the cache: "read-only" applies to OpenCL kernel running on the GPU.
#define VEC_RO(a, b, vecs) auto a##_scoped = ScopedVec(b, vecs, true); auto &a = *(a##_scoped.get());
