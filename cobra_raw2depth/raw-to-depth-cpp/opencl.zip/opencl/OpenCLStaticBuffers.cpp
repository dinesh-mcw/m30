#include "OpenCLStaticBuffers.h"
#include "RtdVec.h"
#include "RawToDepthDsp.h"
#include "RtdMetadata.h"
#include "LumoTimers.h"


OpenCLStaticBuffers::OpenCLStaticBuffers(GpuProps &props) : 
  _props(props)
{
  _pixelMask = std::make_shared<std::vector<uint16_t>>(IMAGE_WIDTH * MAX_IMAGE_HEIGHT, 0xffff);
}

OpenCLStaticBuffers::~OpenCLStaticBuffers()
{
}

// The generalized median filter function uses this looking table to index away from the current image coordinates.
OpenCLStaticBuffers::MedianFilterOffsetsTable &OpenCLStaticBuffers::getMedianFilterOffsets(std::vector<uint32_t> kernelIndices, std::vector<uint32_t> frameSize)
{
  for (auto &b : _medianFilterOffsetsTables)
  {
    if (b->kernelIndices == kernelIndices && b->frameSize == frameSize)
    {
      return *b;
    }
  }

  auto offsets = RawToDepthDsp::getMedianOffsets(frameSize, kernelIndices);
  auto table = std::make_shared<MedianFilterOffsetsTable>();

  cl_int errNum;
  table->buffer = clCreateBuffer(_props.openclContext, CL_MEM_READ_ONLY, sizeof(int32_t) * offsets.size(), nullptr, &errNum);
  RtdVec::errorCheck(errNum, "OpenCLStaticBuffers::getMedianFilterOffsets() - clCreateBuffer");

  bool blocking_write = false;
  cl_event event;
  errNum = clEnqueueWriteBuffer(_props.commandQueue, table->buffer, blocking_write, 0, sizeof(int32_t) * offsets.size(), (void *)offsets.data(), 0, nullptr, &event);
  RtdVec::errorCheck(errNum, "OpenCLStaticBuffers::MedianFilterOffsetsTable() - clEnqueueWriteBuffer()");
  _props.profiler.get("OpenCLStaticBuffers::getMedianFilterOffsets")->add(event);

  table->frameSize = frameSize;
  table->kernelIndices = kernelIndices;
  table->numOffsets = offsets.size();
  table->margins = std::vector<uint32_t>({uint32_t(RawToDepthDsp::_fKernels[kernelIndices[0]].size()) / 2,
                                          uint32_t(RawToDepthDsp::_fKernels[kernelIndices[1]].size()) / 2});
  _medianFilterOffsetsTables.push_back(table);
  return *table;
}


bool OpenCLStaticBuffers::realloc(uint32_t size) 
{
  if (size == 0) return false;
  bool changed = _frameSize != size;
  
  reallocFrame(_frameBuffer, size*FRAME_BUFFER_NUM_FRAMES); // raw0/1, phase0/1, signal, snr, background
  reallocMask(_maskBuffer, size); // pixelMask, range, signal, snr, background
  _frameSize = size;

  const cl_float zeros = 0.0F;
  cl_event event;
  size_t offset = getOffsetToSnrBuffer();
  cl_int res = clEnqueueFillBuffer(_props.commandQueue, _frameBuffer->vec, &zeros, sizeof(cl_float), offset, sizeof(cl_float)*size, 0, nullptr, &event);
  RtdVec::errorCheck(res, "OpenCLStaticBuffers::realloc - clEnqueueFillBuffer");
  _props.profiler.get("SNR Prefill")->add(event);
  return changed;
}

void OpenCLStaticBuffers::reallocMask(std::shared_ptr<RtdSVec> &maskFrames, uint32_t frameSize)
{
  bool realloc = (nullptr == maskFrames);
  if (!realloc)
    realloc = maskFrames->size() != MASKED_BUFFER_TOTAL_SIZE(frameSize);
  if (realloc)
  {
    maskFrames = std::make_shared<RtdSVec>(MASKED_BUFFER_TOTAL_SIZE(frameSize), _props);
    maskFrames->copydown(*_pixelMask, _props, MASKED_BUFFER_MASK_OFFSET(frameSize)); 
  }
}

void OpenCLStaticBuffers::reallocFrame(std::shared_ptr<RtdVec> &frame, uint32_t frameSize)
{
  bool realloc = (nullptr == frame);
  if (!realloc)
    realloc = frame->size() != frameSize;
  if (realloc)
  {
    frame = std::make_shared<RtdVec>(frameSize, _props);
  }
} 


std::shared_ptr<RtdVec> OpenCLStaticBuffers::getRoiBuffer(std::vector<float_t> &cpuRoi)
{
  _roiPingOrPong = (int)(!_roiPingOrPong);
  static LumoTimers _timers("OpenCLStaticBuffers::getRoiBuffer");
  {
    if (_roiPingPongBuffer.empty())
    {
        _roiPingPongBuffer = { std::make_shared<RtdVec>(cpuRoi.size(), _props), std::make_shared<RtdVec>(cpuRoi.size(), _props) };
    }
    if (_roiPingPongBuffer[_roiPingOrPong]->size() != cpuRoi.size())
    {
      _roiPingPongBuffer[_roiPingOrPong] = std::make_shared<RtdVec>(cpuRoi.size(), _props);
    }

    {
      cl_bool blocking_write = CL_TRUE;
      cl_int res;
      cl_event event;
      res = clEnqueueWriteBuffer(_props.commandQueue, _roiPingPongBuffer[_roiPingOrPong]->vec, blocking_write, 0, sizeof(float_t)*cpuRoi.size(), (void*)cpuRoi.data(), 0, nullptr, &event);
      RtdVec::errorCheck(res, "OpenCLStaticBuffers::getRoiBuffer() - clEnqueueWriteBuffer");
      _props.profiler.get("OpenCLStaticBuffers::getRoiBuffer - copydown")->add(event);
    }
  }
  _timers.report();
  
  return _roiPingPongBuffer[_roiPingOrPong];
}
