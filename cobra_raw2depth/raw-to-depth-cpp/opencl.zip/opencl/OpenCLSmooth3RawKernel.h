#pragma once

#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "OpenCLKernels.h"
#include <vector>

// Fixed-size horizontal 3-point smoothing function.
class OpenCLSmooth3RawKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_smooth3Raw_code;
  static const char *cl_smooth3Raw_name;

public:
  OpenCLSmooth3RawKernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &in, RtdVec &out, RtdVec &k3, std::vector<uint32_t> size);
};