#include "OpenCLProcessRoiKernel.h"
#include "OpenCLBinMxMKernel.h"
#include "OpenCLBin1x1Kernel.h"
#include "OpenCLCalculatePhaseKernel.h"
#include "RawToDepthDsp.h"
#include "LumoUtil.h"
#include "RtdMetadata.h"
#include "OpenCLStaticBuffers.h"

// Combined kernels for speed optimization. High CPU cost for enqueueing the kernel.
const char *OpenCLProcessRoiKernel::cl_process_roi_code = "  \n\
  \n\
" BIN_MXM_FUNCTION(2, 0.25f)  "  \n\
" BIN_MXM_FUNCTION(4, 0.0625f)  "  \n\
" BIN_1X1_FUNCTION "  \n\
" CALCULATE_PHASE_FUNCTION "  \n\
#define FRAME_BUFFER_RAW_OFFSET(frameSize, frqIdx) " STRINGIFY(FRAME_BUFFER_RAW_OFFSET(frameSize, frqIdx)) "  \n\
#define FRAME_BUFFER_PHASE_OFFSET(frameSize, frqIdx) "  STRINGIFY(FRAME_BUFFER_PHASE_OFFSET(frameSize, frqIdx)) "  \n\
#define FRAME_BUFFER_SIGNAL_OFFSET(frameSize) "  STRINGIFY(FRAME_BUFFER_SIGNAL_OFFSET(frameSize)) "  \n\
#define FRAME_BUFFER_SNR_OFFSET(frameSize) " STRINGIFY(FRAME_BUFFER_SNR_OFFSET(frameSize)) "  \n\
#define FRAME_BUFFER_BACKGROUND_OFFSET(frameSize) " STRINGIFY(FRAME_BUFFER_BACKGROUND_OFFSET(frameSize)) "  \n\
\n\
#define ROI_PRODUCTS_SIZE(roiBinnedSize)  " STRINGIFY(ROI_PRODUCTS_SIZE(roiBinnedSize)) "  \n\
#define ROI_PRODUCTS_OFFSET_TO_PHASE(roiBufferLength, frqIdx) " STRINGIFY(ROI_PRODUCTS_OFFSET_TO_PHASE(roiBufferLength, frqIdx)) "  \n\
#define ROI_PRODUCTS_OFFSET_TO_SIGNAL(roiBinnedSize, frqIdx) " STRINGIFY(ROI_PRODUCTS_OFFSET_TO_SIGNAL(roiBinnedSize, frqIdx))  "  \n\
#define ROI_PRODUCTS_OFFSET_TO_SNR(roiBinnedSize) " STRINGIFY(ROI_PRODUCTS_OFFSET_TO_SNR(roiBinnedSize)) "  \n\
#define ROI_PRODUCTS_OFFSET_TO_BACKGROUND(roiBinnedSize, frqIdx) " STRINGIFY(ROI_PRODUCTS_OFFSET_TO_BACKGROUND(roiBinnedSize, frqIdx)) "  \n\
\n\
__kernel void cl_process_roi(const __global float *rawRoi, \n\
                                   __global float *frameOut,  \n\
                                   int roiWidth, \n\
                                   int roiHeight, \n\
                                   int binning, \n\
                                   int roiRow, int roiCol,  \n\
                                   int imageWidth, int imageHeight,  \n\
                                   float binningFactor) {  \n\
  int work_dim = (int)get_work_dim(); \n\
  if (work_dim != 2) return; \n\
  int roiX = (int)get_global_id(0); /* output coords. */\n\
  int roiY = (int)get_global_id(1); \n\
  if (roiX >= roiWidth || roiY >= roiHeight) return; \n\
  \n\
  // ----------------------------- Binning ---------------------- \n\
  // Compute the binned raw value for f0  \n\
  float3 raw0, raw1; // This is gpixel data, 3-phases per raw data point. \n\
  if (binning == 1) {  \n\
    raw0 = bin_1x1(rawRoi, roiX, roiY, roiWidth);  \n\
    raw1 = bin_1x1(rawRoi, roiX, roiY + roiHeight, roiWidth);  \n\
  }  \n\
  else if (binning == 2) {  \n\
    raw0 = bin_2x2(rawRoi, roiX, roiY, roiWidth);  \n\
    raw1 = bin_2x2(rawRoi, roiX, roiY + roiHeight, roiWidth);  \n\
  }  \n\
  else if (binning == 4) {  \n\
    raw0 = bin_4x4(rawRoi, roiX, roiY, roiWidth);  \n\
    raw1 = bin_4x4(rawRoi, roiX, roiY + roiHeight, roiWidth);  \n\
  }  \n\
  int roiBufferLength = roiWidth*roiHeight;  \n\
  int roiIdx = roiX + roiWidth*roiY;  \n\
  \n\
  // ---------------------------- CalculatePhase ----------------------- \n\
    \n\
    int frqIdx = 0;  \n\
    float phase0, signal0, background0, snr0;  \n\
    calculate_phase(raw0.x, raw0.y, raw0.z, phase0, signal0, background0, snr0, binningFactor);  \n\
    \n\
    frqIdx = 1;  \n\
    float phase1, signal1, background1, snr1;   \n\
    calculate_phase(raw1.x, raw1.y, raw1.z, phase1, signal1, background1, snr1, binningFactor);  \n\
    \n\
  \n\
  //  -------------------------- snr-voting  ----------------------------  \n\
  {  \n\
    int frameBufferLength = imageWidth*imageHeight;  \n\
    __global float *raw0Frame       = frameOut + FRAME_BUFFER_RAW_OFFSET(frameBufferLength, 0);  \n\
    __global float *raw1Frame       = frameOut + FRAME_BUFFER_RAW_OFFSET(frameBufferLength, 1);  \n\
    __global float *phase0Frame     = frameOut + FRAME_BUFFER_PHASE_OFFSET(frameBufferLength, 0);  \n\
    __global float *phase1Frame     = frameOut + FRAME_BUFFER_PHASE_OFFSET(frameBufferLength, 1);  \n\
    __global float *signalFrame     = frameOut + FRAME_BUFFER_SIGNAL_OFFSET(frameBufferLength);  \n\
    __global float *snrFrame        = frameOut + FRAME_BUFFER_SNR_OFFSET(frameBufferLength);  \n\
    __global float *backgroundFrame = frameOut + FRAME_BUFFER_BACKGROUND_OFFSET(frameBufferLength);  \n\
    float newSnr = snr0+snr1;  \n\
    int frameIdx = (roiX + roiCol) + imageWidth * (roiRow + roiY);  \n\
    float oldSnr = snrFrame[frameIdx];  \n\
    if (oldSnr >= newSnr) return;  \n\
    vstore3(raw0, frameIdx, raw0Frame);  \n\
    vstore3(raw1, frameIdx, raw1Frame);  \n\
    phase0Frame[frameIdx]     = phase0;  \n\
    phase1Frame[frameIdx]     = phase1;  \n\
    snrFrame[frameIdx]        = newSnr;  \n\
    signalFrame[frameIdx]     = signal0     + signal1;  \n\
    backgroundFrame[frameIdx] = background0 + background1;  \n\
  }  \n\
}";
const char *OpenCLProcessRoiKernel::cl_process_roi_name = "cl_process_roi";

OpenCLProcessRoiKernel::OpenCLProcessRoiKernel(OpenCLKernels &kernels) :
  _openCLKernel(kernels.getKernel(cl_process_roi_name, cl_process_roi_code)) {}


void OpenCLProcessRoiKernel::enqueue(std::shared_ptr<RtdVec> rawRoi, 
                                     std::shared_ptr<RtdVec> frameBuffer, 
                                     cl_int BINNING, 
                                     std::vector<uint32_t> roiSize, 
                                    cl_int roiRow, cl_int roiCol,
                                    cl_int imageWidth, cl_int imageHeight,
                                    uint32_t numberOfSummedValues)
{
  assert(rawRoi->size() == 2*roiSize[0]*roiSize[1]*NUM_GPIXEL_PHASES);
  assert(0 == roiSize[0] % BINNING);
  assert(0 == roiSize[1] % BINNING);
  cl_int roiWidth = roiSize[1]/BINNING; // count of raw triplets
  cl_int roiHeight = roiSize[0]/BINNING; // both frequencies are stacked, but two freqs are computed on each kernel call.

  cl_float binningFactor = roundf(SNR_SCALING_FACTOR * sqrtf(float(numberOfSummedValues)/float_t(RAW_SCALING_FACTOR)));

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void*)(&rawRoi->vec));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void*)(&frameBuffer->vec));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_int), (void*)(&roiWidth));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(cl_int), (void*)(&roiHeight));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(cl_int), (void*)(&BINNING));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 4");

  res = clSetKernelArg(_openCLKernel->getKernel(), 5, sizeof(cl_int), (void*)(&roiRow));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 5");

  res = clSetKernelArg(_openCLKernel->getKernel(), 6, sizeof(cl_int), (void*)(&roiCol));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 6");

  res = clSetKernelArg(_openCLKernel->getKernel(), 7, sizeof(cl_int), (void*)(&imageWidth));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 7");

  res = clSetKernelArg(_openCLKernel->getKernel(), 8, sizeof(cl_int), (void*)(&imageHeight));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 8");

  res = clSetKernelArg(_openCLKernel->getKernel(), 9, sizeof(cl_float), (void*)(&binningFactor));
  RtdVec::errorCheck(res, "OpenCLProcessRoiKernel::enqueue() - clSetKernelArg 9");

  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8, 4};
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(roiWidth, local_work_size[0]),
                                LumoUtil::roundToMultiple(roiHeight, local_work_size[1])};

  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), 2, nullptr, global_work_size, local_work_size, 0, nullptr, &_event);
  RtdVec::errorCheck(err, "OpenCLProcessRoiKernel::enqueue - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLProcessRoiKernel")->add(_event);
}