#include "RawToDepthV2_opencl.h"
#include "LumoUtil.h"
#include "ScopedVec.h"
#include "OpenCLMaskKernel.h"
#include "OpenCLComputeWholeFrameRangeKernel.h"
#include "OpenCLMinMaxKernel.h"
#include "OpenCLCalcPhaseSmoothKernel.h"
#include "OpenCLMedianPlus5x7Kernel.h"
#include "OpenCLMedianPlus2x3Kernel.h"
#include "OpenCLMedianFilterPlusKernel.h"
#include <LumoTimers.h>

// Called once every 91 ROIs with 320x240 image _size at 10Hz.
void RawToDepthV2_opencl::processWholeFrame()
{
  if (!_firstRoiReceived)
    return; // Do no processing if the first ROI was never received.
  
  _processRoiThread.wait(); // 
  
  uint32_t totalTime=0;
  //auto localTimer = LumoTimers::ScopedTimer(_timers, "RawToDepthV2_opencl::processWholeFrame()", TIMERS_UPDATE_EVERY);

  uint32_t imsize = _size[0]*_size[1];
  VEC(dCorrectedPhases0, imsize, _platform.getVecs());
  VEC(dCorrectedPhases1, imsize, _platform.getVecs());
  VEC(dSmoothedPhases1, imsize, _platform.getVecs());
  VEC(dSmoothedPhases0, imsize, _platform.getVecs());

  auto frameBuffer = _platform.getStaticBuffers().getFrameBuffer();
  {
    VEC(df0Smoothed, NUM_GPIXEL_PHASES*imsize, _platform.getVecs());
    {
      smoothSummedData(*frameBuffer, df0Smoothed, _size, _rowKernelIdx, _columnKernelIdx, 0, _platform);
    }

    VEC(df1Smoothed, NUM_GPIXEL_PHASES*imsize, _platform.getVecs());
    {
      smoothSummedData(*frameBuffer, df1Smoothed, _size, _rowKernelIdx, _columnKernelIdx, 1, _platform);
    }

    auto calculatePhaseSmoothKernel = OpenCLCalcPhaseSmoothKernel(_platform.getKernels());
    {
      uint32_t frameBufferOffset = _platform.getStaticBuffers().getOffsetToPhaseBuffer(0); // offset to phase0 or phase1
      calculatePhaseSmoothKernel.enqueue(df0Smoothed, dSmoothedPhases0, *frameBuffer, dCorrectedPhases0, imsize, frameBufferOffset);
    }

    {
      uint32_t frameBufferOffset = _platform.getStaticBuffers().getOffsetToPhaseBuffer(1); // offset to phase0 or phase1
      calculatePhaseSmoothKernel.enqueue(df1Smoothed, dSmoothedPhases1, *frameBuffer, dCorrectedPhases1, imsize, frameBufferOffset);

    }
  }

  // Frame Buffer: raw0/1, phase0/1, signal, snr, background
  VEC(dRanges, imsize, _platform.getVecs());
  VEC(dMFrame, imsize, _platform.getVecs());
  VEC(dMinMaxMask, imsize, _platform.getVecs());
  {

    auto kernel = OpenCLComputeWholeFrameRangeKernel(_platform.getKernels());
    kernel.enqueue(dSmoothedPhases0, dSmoothedPhases1, dCorrectedPhases0, dCorrectedPhases1, dRanges, _fs, _fsInt, dMFrame);

    auto minMaxKernel = OpenCLMinMaxKernel(_platform.getKernels());
    minMaxKernel.enqueue(dMFrame, dMinMaxMask, _minMaxFilterSize, _size, 1.0F);

  }

  VEC(dRangesMedian, imsize, _platform.getVecs());
  {
    std::vector<uint32_t> kernelIndices = {_rowKernelIdx, _columnKernelIdx};
    if (kernelIndices == std::vector<uint32_t>({2,3}))
    {
      auto k = OpenCLMedianPlus5x7Kernel(_platform.getKernels());
      k.enqueue(dRanges, dRangesMedian, _size, _performGhostMedian);
    }
    else if (kernelIndices == std::vector<uint32_t>({1,2}))
    {
      auto k = OpenCLMedianPlus2x3Kernel(_platform.getKernels());
      k.enqueue(dRanges, dRangesMedian, _size, _performGhostMedian);
    }
    else
    {
     // Unoptimized filter for 1x1 binning.
      auto &offsets = _platform.getStaticBuffers().getMedianFilterOffsets(kernelIndices, _size);
      
      auto k = OpenCLMedianFilterPlusKernel(_platform.getKernels());
      k.enqueue(dRanges, dRangesMedian, offsets.buffer, offsets.numOffsets, offsets.margins, _size, _performGhostMedian);
    }

  }

  // Masks range and converts all output frames to short for transmission.
  auto maskKernel = OpenCLMaskKernel(_platform.getKernels());
  maskKernel.enqueue(dRangesMedian, 
                     *frameBuffer, 
                     dMinMaxMask,  
                     _platform.getStaticBuffers().getMaskBuffer(), 
                     _size, _snrThresh, _disableRangeMasking, _maxRangeThresh, _fovStart, _fovStep, _fovSize);
  
  
  auto t = LumoTimers::ScopedTimer(_timers, "processWholeFrame_opencl - copyout", TIMERS_UPDATE_EVERY);

  _ranges = std::make_shared<std::vector<uint16_t>>(_size[0]*_size[1]);
  _platform.getStaticBuffers().getMaskBuffer().copyout(*_ranges, _platform.getProps(), MASKED_BUFFER_RANGE_OFFSET(_size[0]*_size[1]));

  _snr = std::make_shared<std::vector<uint16_t>>(_size[0]*_size[1]);
  _platform.getStaticBuffers().getMaskBuffer().copyout(*_snr, _platform.getProps(), MASKED_BUFFER_SNR_OFFSET(_size[0]*_size[1]));

  _background = std::make_shared<std::vector<uint16_t>>(_size[0]*_size[1]);
  _platform.getStaticBuffers().getMaskBuffer().copyout(*_background, _platform.getProps(), MASKED_BUFFER_BACKGROUND_OFFSET(_size[0]*_size[1]));

  _signals = std::make_shared<std::vector<uint16_t>>(_size[0]*_size[1]);
  _platform.getStaticBuffers().getMaskBuffer().copyout(*_signals, _platform.getProps(), MASKED_BUFFER_SIGNAL_OFFSET(_size[0]*_size[1]));
}
