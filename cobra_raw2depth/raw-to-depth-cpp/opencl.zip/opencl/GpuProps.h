#pragma once
#include <CL/cl.h>
#include "OpenCLProfiler.h"

class GpuProps 
{
public:
  GpuProps();
  void wait();
  cl_context openclContext;
  cl_command_queue commandQueue;
  cl_device_id deviceId;
  size_t workGroupSize=32;
  OpenCLProfiler profiler;
};