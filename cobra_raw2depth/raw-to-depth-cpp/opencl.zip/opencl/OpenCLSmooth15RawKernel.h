#pragma once

#include "OpenCLKernel.h"
#include "RawToDepthPlatform.h"
#include "RtdVec.h"
#include <vector>

class OpenCLSmooth15RawKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_smooth15Raw_code;
  static const char *cl_smooth15Raw_name;

public:
  OpenCLSmooth15RawKernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &in, RtdVec &out, RtdVec &k15, std::vector<uint32_t> size);
};