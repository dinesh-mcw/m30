#pragma once

#include "CL/cl.h"
#include "GpuProps.h"
#include "RtdVec.h"
#include "RtdSVec.h"
#include "RtdMetadata.h"
#include <memory>
#include <vector>

// ROI products is a transient array allocated in the cache.
// It contains several components. Here's how to compute the  offset within the buffer to each component.
#define ROI_PRODUCTS_SIZE(roiBinnedSize) (roiBinnedSize*(2 + 2 + 1 + 2))
#define ROI_PRODUCTS_OFFSET_TO_PHASE(roiBinnedSize, frqIdx) (roiBinnedSize*frqIdx)
#define ROI_PRODUCTS_OFFSET_TO_SIGNAL(roiBinnedSize, frqIdx) (ROI_PRODUCTS_OFFSET_TO_PHASE(roiBinnedSize, 1) + roiBinnedSize*(1+frqIdx))
#define ROI_PRODUCTS_OFFSET_TO_SNR(roiBinnedSize) (ROI_PRODUCTS_OFFSET_TO_SIGNAL(roiBinnedSize, 1) + roiBinnedSize)
#define ROI_PRODUCTS_OFFSET_TO_BACKGROUND(roiBinnedSize, frqIdx) (ROI_PRODUCTS_OFFSET_TO_SNR(roiBinnedSize) + roiBinnedSize*(1+frqIdx))

// Frame Buffer: raw0/1, phase0/1, signal, snr, background
#define FRAME_BUFFER_NUM_FRAMES (2*NUM_GPIXEL_PHASES + 5)
#define FRAME_BUFFER_RAW_OFFSET(frameSize, frqIdx) (frqIdx*NUM_GPIXEL_PHASES*frameSize)
#define FRAME_BUFFER_PHASE_OFFSET(frameSize, frqIdx) (FRAME_BUFFER_RAW_OFFSET(frameSize, 1) + NUM_GPIXEL_PHASES*frameSize + frqIdx*frameSize)
#define FRAME_BUFFER_SIGNAL_OFFSET(frameSize) (FRAME_BUFFER_PHASE_OFFSET(frameSize, 1) + frameSize)
#define FRAME_BUFFER_SNR_OFFSET(frameSize) (FRAME_BUFFER_SIGNAL_OFFSET(frameSize) + frameSize)
#define FRAME_BUFFER_BACKGROUND_OFFSET(frameSize) (FRAME_BUFFER_SNR_OFFSET(frameSize) + frameSize)

#define MASKED_BUFFER_NUM_FRAMES 5 // pixelMask, range, snr, background, signal
#define MASKED_BUFFER_TOTAL_SIZE(frameSize) (IMAGE_WIDTH * MAX_IMAGE_HEIGHT + 4 * frameSize)
#define MASKED_BUFFER_MASK_OFFSET(frameSize)       (0)
#define MASKED_BUFFER_RANGE_OFFSET(frameSize)      (IMAGE_WIDTH * MAX_IMAGE_HEIGHT + 0 * frameSize)
#define MASKED_BUFFER_SIGNAL_OFFSET(frameSize)     (IMAGE_WIDTH * MAX_IMAGE_HEIGHT + 1 * frameSize)
#define MASKED_BUFFER_SNR_OFFSET(frameSize)        (IMAGE_WIDTH * MAX_IMAGE_HEIGHT + 2 * frameSize)
#define MASKED_BUFFER_BACKGROUND_OFFSET(frameSize) (IMAGE_WIDTH * MAX_IMAGE_HEIGHT + 3 * frameSize)


// OpenCL device buffers created at startup time and remain throughout the runtime of the application.
// 
class OpenCLStaticBuffers
{
public:
  struct MedianFilterOffsetsTable
  {
    cl_mem buffer;
    std::vector<uint32_t> frameSize;
    std::vector<uint32_t> kernelIndices;
    uint32_t numOffsets;
    std::vector<uint32_t> margins;
  };

private:

  GpuProps &_props;
  std::vector<std::shared_ptr<MedianFilterOffsetsTable>> _medianFilterOffsetsTables;

  std::shared_ptr<RtdVec> _frameBuffer = nullptr;
  uint32_t _frameSize=0;

  std::vector<std::shared_ptr<RtdVec>> _roiPingPongBuffer;
  uint32_t _roiPingOrPong = 0; // holds the index to the ping pong buffer currently valid

  std::shared_ptr<RtdSVec> _maskBuffer = nullptr;
  std::shared_ptr<std::vector<uint16_t>> _pixelMask;

public:
  OpenCLStaticBuffers(GpuProps &props);
  ~OpenCLStaticBuffers();

  MedianFilterOffsetsTable &getMedianFilterOffsets(std::vector<uint32_t> kernelIndices, std::vector<uint32_t> frameSize);
  
  bool realloc(uint32_t size);
  std::shared_ptr<RtdVec> getFrameBuffer() { return _frameBuffer; }

  uint32_t getOffsetToRawBuffer(uint32_t frqIdx) { return FRAME_BUFFER_RAW_OFFSET(_frameSize, frqIdx); }
  uint32_t getOffsetToPhaseBuffer(uint32_t frqIdx) { return FRAME_BUFFER_PHASE_OFFSET(_frameSize, frqIdx); }
  uint32_t getOffsetToSignalBuffer() { return FRAME_BUFFER_SIGNAL_OFFSET(_frameSize); }
  uint32_t getOffsetToSnrBuffer() { return FRAME_BUFFER_SNR_OFFSET(_frameSize); }
  uint32_t getOffsetToBackgroundBuffer() { return FRAME_BUFFER_BACKGROUND_OFFSET(_frameSize); }
  uint32_t getFrameBufferSize() { return FRAME_BUFFER_NUM_FRAMES * _frameSize; }

  RtdSVec &getMaskBuffer() { return *_maskBuffer; }
  void setPixelMask(std::shared_ptr<std::vector<uint16_t>> pixelMask) 
  { 
    _pixelMask = pixelMask; 
    _maskBuffer->copydown(*_pixelMask, _props, MASKED_BUFFER_MASK_OFFSET(_frameSize));
  }

  std::shared_ptr<RtdVec> getRoiBuffer(std::vector<float_t> &cpuRoi);

private:
  void reallocFrame(std::shared_ptr<RtdVec> &frame, uint32_t frameSize);
  void reallocMask(std::shared_ptr<RtdSVec> &maskFrames, uint32_t frameSize);
};
