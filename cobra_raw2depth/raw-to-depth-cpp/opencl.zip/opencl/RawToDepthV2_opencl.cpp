#include "RawToDepthV2_opencl.h"
#include "RawToDepthDsp.h"
#include "RtdMetadata.h"
#include "LumoUtil.h"
#include <cmath>
#include <LumoLogger.h>
#include <LumoTimers.h>
#include <cassert>
#include <sstream>

RawToDepthV2_opencl::RawToDepthV2_opencl(uint32_t fovIdx, uint32_t headerNum) :
  RawToDepth(fovIdx, headerNum),
  _processRoiThread(OpenCLProcessRoiKernel(_platform.getKernels())) {
  realloc((uint16_t*)RtdMetadata::DEFAULT_METADATA.data(), uint32_t(RtdMetadata::DEFAULT_METADATA.size()*sizeof(uint16_t)));

  std::ostringstream id; id << std::setw(4) << std::setfill('0') << "RawToDepthV2_opencl_" << _headerNum;
  LumoLogger::setId(id.str());

}

void RawToDepthV2_opencl::reset(uint16_t *md, uint32_t mdBytes) {
  RawToDepth::reset(md, mdBytes);
  realloc(md, mdBytes);
}

void RawToDepthV2_opencl::realloc(uint16_t *mdPtr, uint32_t mdBytes)
{
  auto imsize = _size[0] * _size[1];
  auto md = RtdMetadata(mdPtr, mdBytes);

  bool changed = false;
  
  if (md.getBinningY(_fovIdx) == 1)
      _rowKernelIdx = 3;
      
  if (md.getBinningY(_fovIdx) == 2)
    _rowKernelIdx = 2; // 5-tap filter

  if (md.getBinningY(_fovIdx) == 4)
    _rowKernelIdx = 1; // 3-tap filter
   
  if (md.getBinningX(_fovIdx) == 1)
    _columnKernelIdx = 6;
  
  if (md.getBinningX(_fovIdx) == 2)
    _columnKernelIdx = 3; // 7-tap filter

  if (md.getBinningX(_fovIdx) == 4)
    _columnKernelIdx = 2; // 5-tap filter

  if (md.getDisablePhaseSmoothing(_fovIdx)) {
    _rowKernelIdx=0;
    _columnKernelIdx=0;
  }

  _minMaxFilterSize = {};
  if (md.getPerformGhostMinMaxFilter(_fovIdx)) {
    uint32_t vMinMaxSize = (RawToDepthDsp::_fKernels[_rowKernelIdx].size()/2) & 0x01;
    uint32_t hMinMaxSize = (RawToDepthDsp::_fKernels[_columnKernelIdx].size()/2) & 0x01;
    if (vMinMaxSize < 3) vMinMaxSize = 3;
    if (hMinMaxSize < 3) hMinMaxSize = 3;
    _minMaxFilterSize = {vMinMaxSize, hMinMaxSize};
  }

  changed |= _platform.getStaticBuffers().realloc(imsize);
  if (changed) {
    _platform.getVecs().clear();
  }

}

void RawToDepthV2_opencl::loadPixelMask(std::string pixelMaskFilename) 
{
  RawToDepth::loadPixelMask(pixelMaskFilename);
  _platform.getStaticBuffers().setPixelMask(_pixelMask);
}
