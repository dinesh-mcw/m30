#pragma once
#include "RtdVec.h"
#include "OpenCLProcessRoiKernel.h"
#include <mutex>
#include <condition_variable>
#include <future>

class ProcessRoiThread
{
private:
  std::mutex _mutex;
  std::condition_variable _condition_variable;
  OpenCLProcessRoiKernel _kernel;
  bool _quitNow = false;
  bool _dataReady  = false;
  bool _kernelRunning = false;
  std::future<void> _future;

  std::shared_ptr<RtdVec> _dRoi;
  std::shared_ptr<RtdVec> _dFrameBuffer;
  cl_int _binningY;
  std::vector<uint32_t> _roiSize;
  cl_int _roiRow; cl_int _roiCol;
  cl_int _imageWidth; cl_int _imageHeight;
  uint32_t _numberOfSummedValues;

public:
  ProcessRoiThread(OpenCLProcessRoiKernel kernel);
  ~ProcessRoiThread();
  static void run(ProcessRoiThread *inst);
  void set(std::shared_ptr<RtdVec> rawRoi,
               std::shared_ptr<RtdVec>frameBuffer, 
               cl_int BINNING,  
               std::vector<uint32_t> roiSize, 
               cl_int roiRow, cl_int roiCol,
               cl_int imageWidth, cl_int imageHeight,
               uint32_t numberOfSummedValues);
  static void CL_CALLBACK kernelDone(cl_event event, cl_int status, void *inst);
  void wait();
};