#pragma once

#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "OpenCLKernels.h"
#include <vector>

// Generalized median filter.
// Uses a lookup table for pixel offsets from current coordinate.
class OpenCLMedianFilterPlusKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_medianFilterPlus_code;
  static const char *cl_medianFilterPlus_name;

public:
  OpenCLMedianFilterPlusKernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &in, RtdVec &out, cl_mem &offsets, uint32_t numOffsets, std::vector<uint32_t> margins, std::vector<uint32_t> frameSize, bool performGhostMedian);
};