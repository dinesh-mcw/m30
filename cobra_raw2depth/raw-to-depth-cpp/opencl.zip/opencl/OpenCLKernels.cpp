#include "OpenCLKernels.h"
#include <algorithm>

// Cache for holding OpenCL kernel/programs once compiled.
OpenCLKernels::OpenCLKernels(GpuProps &props) :
  _props(props)
{

}
std::shared_ptr<OpenCLKernel> OpenCLKernels::getKernel(std::string functionName, std::string code)
{
  // std::map requires a default ctor for items.
  uint32_t idx;
  for (idx=0; idx<_functionNames.size(); idx++) 
  {
    if (_functionNames[idx] == functionName) break;
  }

  if (idx >= _functionNames.size())
  {
    _kernels.emplace_back(std::make_shared<OpenCLKernel>(_props, functionName, code));
    _functionNames.push_back(functionName);
  }
  return _kernels[idx];
}

OpenCLKernels::~OpenCLKernels()
{
  for (auto k : _kernels)
  {
    clReleaseKernel(k->getKernel());
  }
}