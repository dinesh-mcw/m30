#pragma once

#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "RtdSVec.h"
#include "OpenCLKernels.h"
#include <vector>

// Performs masking to block out non-luminated pixels.
// Also performs float-to-short conversion on output components
// for network transport.
class OpenCLMaskKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_mask_code;
  static const char *cl_mask_name;

public:
  OpenCLMaskKernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &dRanges, 
               RtdVec &dFrameBuffer, 
               RtdVec &minMaxMask, 
               RtdSVec &dMaskBuffer, 
               std::vector<uint32_t> size,
               float snrThresh, bool disableRangeMasking, float maxRangeThresh, 
               std::vector<uint16_t> fovStart, 
               std::vector<uint16_t> fovStep, 
               std::vector<uint16_t> fovSize);
};