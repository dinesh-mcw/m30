#pragma once

#include "OpenCLKernel.h"
#include "RtdVec.h"
#include "OpenCLKernels.h"
#include <vector>

class OpenCLMinMaxKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_minMax_code;
  static const char *cl_minMax_name;

public:
  OpenCLMinMaxKernel(OpenCLKernels &kernels);
  void enqueue(const RtdVec &frame, RtdVec &minMaxMask, std::vector<uint32_t> filterSize, std::vector<uint32_t> frameSize, float_t minMaxThresh);
};