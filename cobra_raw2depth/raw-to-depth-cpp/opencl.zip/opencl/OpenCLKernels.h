#pragma once
#include <vector>
#include <memory>
#include "OpenCLKernel.h"

class OpenCLKernels
{
  private:
  GpuProps &_props;
  std::vector<std::string> _functionNames;
  std::vector<std::shared_ptr<OpenCLKernel>> _kernels;

  public:
  OpenCLKernels(GpuProps &props);
  std::shared_ptr<OpenCLKernel> getKernel(std::string key, std::string code);
  ~OpenCLKernels();
};

