#include "OpenCLMedianFilterPlusKernel.h"
#include "LumoUtil.h"

const char * OpenCLMedianFilterPlusKernel::cl_medianFilterPlus_code = " \n\
#define MAX_NUM_OFFSETS 21  \n\
__kernel void cl_median_filter_plus_kernel(const __global float *in, __global float *out, \n\
                                           const __constant int *offsets, // Offsets to all the points to sort. \n\
                                           unsigned int numOffsets, \n\
                                           unsigned int hMargin, unsigned int vMargin, \n\
                                           unsigned int imageWidth, unsigned int imageHeight) {  \n\
  int work_dim = (int)get_work_dim(); \n\
  if (work_dim != 2) return; \n\
  float points[MAX_NUM_OFFSETS];  \n\
  int x = (int)get_global_id(0); /* output coords. */\n\
  int y = (int)get_global_id(1); \n\
  if (x >= imageWidth || y >= imageHeight) return;; \n\
  int index = x + y*imageWidth; \n\
  if (x < hMargin || y < vMargin || x >= imageWidth-hMargin || y >= imageHeight-vMargin || numOffsets>MAX_NUM_OFFSETS) {  \n\
    out[index] = in[index];// copy input to output \n\
    return; \n\
  } \n\
  // Insertion sort \n\
  for (int idx=0; idx<numOffsets; idx++) {\n\
    float a = in[index + offsets[idx]];  \n\
    int iidx=0; \n\
    while (iidx < idx) { \n\
      if (a < points[iidx]) break; \n\
      iidx++; \n\
    }  \n\
    int sidx = idx; \n\
    while (sidx > iidx) { \n\
      points[sidx] = points[sidx-1]; \n\
      sidx--;  \n\
    }  \n\
    points[iidx] = a; \n\
  } \n\
  out[index] = points[numOffsets/2];  \n\
    \n\
}";

const char * OpenCLMedianFilterPlusKernel::cl_medianFilterPlus_name = "cl_median_filter_plus_kernel";

OpenCLMedianFilterPlusKernel::OpenCLMedianFilterPlusKernel(OpenCLKernels &kernels) :
  _openCLKernel(kernels.getKernel(cl_medianFilterPlus_name, cl_medianFilterPlus_code)) {}

void OpenCLMedianFilterPlusKernel::enqueue(RtdVec &in, RtdVec &out, cl_mem &offsets, uint32_t numOffsets, std::vector<uint32_t> margins, std::vector<uint32_t> frameSize, bool performGhostMedian)
{

  cl_int res;
  assert(in.size() == out.size());
  assert(in.size() == frameSize[0]*frameSize[1]);

  cl_uint hMargin = margins[1];
  cl_uint vMargin = margins[0];
  cl_uint frameWidth = frameSize[1];
  cl_uint frameHeight = frameSize[0];
  cl_uint numPoints = numOffsets;

  if (!performGhostMedian)
  {
    cl_event event;
    cl_int res;
    res = clEnqueueCopyBuffer(_openCLKernel->getProps().commandQueue, in.vec, out.vec, 0, 0, sizeof(float_t)*frameSize[0]*frameSize[1], 0, nullptr, &event);
    RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clEnqueueCopyBuffer");
    _openCLKernel->getProps().profiler.get("OpenCLMedianFilterPlusKernel")->add(event);
    return;
  }

  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&in.vec));
  RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&out.vec));
  RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_mem), (void*)(&offsets));
  RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(cl_uint), (void*)(&numPoints));
  RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(cl_uint), (void*)(&hMargin));
  RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clSetKernelArg 4");

  res = clSetKernelArg(_openCLKernel->getKernel(), 5, sizeof(cl_uint), (void*)(&vMargin));
  RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clSetKernelArg 5");

  res = clSetKernelArg(_openCLKernel->getKernel(), 6, sizeof(cl_uint), (void*)(&frameWidth));
  RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clSetKernelArg 6");

  res = clSetKernelArg(_openCLKernel->getKernel(), 7, sizeof(cl_uint), (void*)(&frameHeight));
  RtdVec::errorCheck(res, "OpenCLMedianFilterPlusKernel::enqueue() - clSetKernelArg 7");

  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8, 4};
  // The number of raw-triplet pixels processed in the image excludes the padding
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(frameWidth, local_work_size[0]),
                                LumoUtil::roundToMultiple(frameHeight, local_work_size[1])};
  
  cl_event event;
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), 2, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLMedianFilterPlusKernel::enqueue() - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLMedianFilterPlusKernel")->add(event);
}