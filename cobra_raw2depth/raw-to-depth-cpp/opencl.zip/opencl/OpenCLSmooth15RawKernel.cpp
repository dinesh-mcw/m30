#include "OpenCLSmooth15RawKernel.h"
#include "OpenCLKernels.h"
#include "LumoUtil.h"
#include "LumoLogger.h"

const char *OpenCLSmooth15RawKernel::cl_smooth15Raw_code = "\
__kernel void cl_smooth15_raw_kernel(const __global float *in, __global float *out, const __constant float *k15, unsigned int inputWidth, unsigned int inputHeight) {\
  size_t work_dim = get_work_dim(); \
  if (work_dim != 2) return; \
  int x = (int)get_global_id(0); /* output coords. */\
  int y = (int)get_global_id(1); \
  int outputWidth = inputWidth;\
  int outputHeight = inputHeight; \
  if (x >= outputWidth || y >= outputHeight) return; \
  int left = x-7;\
  int right = x+7;\
  int offset = left + (int)inputWidth*y; \
  if (offset+7 >= inputWidth*inputHeight) { printf(\"Offset out of range cl_smooth15Raw_kernel x%d y%d\\n\", x, y); return; }\
  float3 sum;\
  sum = vload3(offset+7, in);\
  if (left < 0 || right >= inputWidth) { vstore3(sum, offset+7, out); return; } \
  sum *= k15[7]; \
  sum += vload3(offset, in) * k15[0];\
  sum += vload3(offset+1 , in) * k15[1]; \
  sum += vload3(offset+2 , in) * k15[2]; \
  sum += vload3(offset+3 , in) * k15[3]; \
  sum += vload3(offset+4 , in) * k15[4]; \
  sum += vload3(offset+5 , in) * k15[5]; \
  sum += vload3(offset+6 , in) * k15[6]; \
  sum += vload3(offset+8 , in) * k15[8]; \
  sum += vload3(offset+9 , in) * k15[9]; \
  sum += vload3(offset+10, in) * k15[10]; \
  sum += vload3(offset+11, in) * k15[11]; \
  sum += vload3(offset+12, in) * k15[12]; \
  sum += vload3(offset+13, in) * k15[13]; \
  sum += vload3(offset+14, in) * k15[14]; \
  vstore3(sum, offset+7, out); \
} ";
const char *OpenCLSmooth15RawKernel::cl_smooth15Raw_name = "cl_smooth15_raw_kernel";

OpenCLSmooth15RawKernel::OpenCLSmooth15RawKernel(OpenCLKernels &kernels) : 
  _openCLKernel(kernels.getKernel(cl_smooth15Raw_name, cl_smooth15Raw_code))
{
}

void OpenCLSmooth15RawKernel::enqueue(RtdVec &in, RtdVec &out, RtdVec &k15, std::vector<uint32_t> size)
{
  auto inputWidth = size[1];
  auto inputHeight = size[0];

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&in.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth15RawKernel::enqueue() - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&out.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth15RawKernel::enqueue() - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_mem), (void *)(&k15.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth15RawKernel::enqueue() - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(unsigned int), (void *)(&inputWidth));
  RtdVec::errorCheck(res, "OpenCLSmooth15RawKernel::enqueue() - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(unsigned int), (void *)(&inputHeight));
  RtdVec::errorCheck(res, "OpenCLSmooth15RawKernel::enqueue() - clSetKernelArg 4");


  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8, 4};
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(inputWidth, local_work_size[0]),
                                LumoUtil::roundToMultiple(inputHeight, local_work_size[1])};

  cl_event event;
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), 2, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLSmooth15RawKernel::enqueue - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLSmooth15RawKernel")->add(event);

}
