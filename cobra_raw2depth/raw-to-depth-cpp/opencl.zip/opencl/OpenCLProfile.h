#pragma once
#include <string>
#include <CL/cl.h>
#include <mutex>
#include <list>
#include <cmath>
#include <atomic>


// Accumulates timing for gpu timers for a given tag.
class OpenCLProfile 
{
private:
  std::string _profileTag;
  std::list<cl_event> _events;
  std::mutex _mutex;
  float_t _totalEventTime=0.0F;
  uint32_t _totalNumberOfStartedEvents=0;
  uint32_t _totalNumberOfCompletedEvents=0;

public:
  OpenCLProfile(const std::string tag);
  std::string &getTag() { return _profileTag; }
  void add(cl_event event);
  static void CL_CALLBACK completed(cl_event event, cl_int status, void *user_data);
  float_t getTotalEventTime() { return _totalEventTime; }
  uint32_t getTotalNumberOfStartedEvents() { return _totalNumberOfStartedEvents; }
  uint32_t getTotalNumberOfCompletedEvents() { return _totalNumberOfCompletedEvents; }

};