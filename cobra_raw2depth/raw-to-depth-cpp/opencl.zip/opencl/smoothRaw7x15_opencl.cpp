
#include "RawToDepthV2_opencl.h"
#include "RawToDepthDsp.h"
#include "RawToDepthPlatform.h"
#include "ScopedVec.h"
#include "OpenCLTransposeRawKernel.h"
#include "OpenCLSmooth7RawKernel.h"
#include "OpenCLSmooth15RawKernel.h"
#include "RtdMetadata.h"
#include <cassert>

void RawToDepthV2_opencl::smoothRaw7x15(const RtdVec &dFrameBuffer, RtdVec &dFrameSmoothed, std::vector<uint32_t> frameSize, uint32_t frqIdx, RawToDepthPlatform &platform)
{
  const auto &k7 = RawToDepthDsp::_fKernels[3];
  const auto &k15 = RawToDepthDsp::_fKernels[6];
  
  uint32_t paddedBufferSize = frameSize[0] * 3 * frameSize[1];
  { // scope for local variables.
    VEC_RO(dK15, k15, platform.getVecs());
    VEC_RO(dK7, k7, platform.getVecs());
    VEC(da, paddedBufferSize, platform.getVecs());
    VEC(db, paddedBufferSize, platform.getVecs()); 


    auto transposeKernel = OpenCLTransposeRawKernel(platform.getKernels());
    auto smooth7Kernel = OpenCLSmooth7RawKernel(platform.getKernels());
    auto smooth15Kernel = OpenCLSmooth15RawKernel(platform.getKernels());

    uint32_t frameOffset = platform.getStaticBuffers().getOffsetToRawBuffer(frqIdx);

    transposeKernel.enqueue(dFrameBuffer, db, {frameSize[0], frameSize[1]}, frameOffset);
    smooth15Kernel.enqueue(db, da, dK15, {frameSize[1], frameSize[0]});
    transposeKernel.enqueue(da, db, {frameSize[1], frameSize[0]}, 0);
    smooth7Kernel.enqueue(db, dFrameSmoothed, dK7, {frameSize[0] , frameSize[1]});
  }
}
