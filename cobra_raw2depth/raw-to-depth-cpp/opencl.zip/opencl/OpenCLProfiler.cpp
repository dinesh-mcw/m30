#include "OpenCLProfiler.h"
#include "LumoLogger.h"


std::shared_ptr<OpenCLProfile> OpenCLProfiler::get(const std::string tag)
{
  for (auto &p : _profiles)
  {
    if (p->getTag() == tag)
      return p;
  }

  _profiles.push_back(std::make_shared<OpenCLProfile>(tag));
  return _profiles.back();
}

OpenCLProfiler::~OpenCLProfiler()
{
#ifndef ENABLE_OPENCL_KERNEL_PROFILING
  return;
#endif
  if (_profiles.size() == 0) return;
  float_t totalTimeAllKernels = 0.0F;
  uint32_t totalNumberOfGpuEvents = 0, totalNumberOfCompletedGpuEvents = 0;
  for (auto &profile : _profiles)
  {
    totalTimeAllKernels += profile->getTotalEventTime();
    totalNumberOfGpuEvents += profile->getTotalNumberOfStartedEvents();
    totalNumberOfCompletedGpuEvents += profile->getTotalNumberOfCompletedEvents();
    float_t averageTime = 0.0F;
    float_t totalEventTime = profile->getTotalEventTime();
    if (profile->getTotalNumberOfCompletedEvents() > 0)
      averageTime = totalEventTime/float_t(profile->getTotalNumberOfCompletedEvents());
    else
      continue;
    LumoLogDebug("%-35s: Number of Events %4u/%4u. Total Time (us) %8.2f Average Time (us) %8.2f", profile->getTag().c_str(), profile->getTotalNumberOfCompletedEvents(), profile->getTotalNumberOfCompletedEvents(), totalEventTime, averageTime);
  }
  if (totalNumberOfCompletedGpuEvents > 0)
    LumoLogDebug(  "%-35s: Number of Events %4u/%4u. Total Time (us) %8.2f", "Totals ------ ", totalNumberOfGpuEvents, totalNumberOfCompletedGpuEvents, totalTimeAllKernels);
}