#include "RtdSVec.h"


void RtdSVec::copyout(std::vector<uint16_t> &out, GpuProps &props, uint32_t offset)
{
  cl_bool blocking_read = true;
  cl_event event;
  assert(out.size() + offset <= size());
  auto res = clEnqueueReadBuffer(props.commandQueue, vec, blocking_read, (size_t)offset * sizeof(uint16_t), out.size() * sizeof(uint16_t), (void *)(out.data()), 0, nullptr, &event);
  RtdVec::errorCheck(res, "RtdSVec::copyout - clEnqueueReadBuffer");
  props.profiler.get("copyout")->add(event);
}

void RtdSVec::copydown(std::vector<uint16_t> &in, GpuProps &props, uint32_t offset)
{
  cl_bool blocking_write = true;
  cl_event event;
  assert(in.size() + offset <= size());
  auto res = clEnqueueWriteBuffer(props.commandQueue, vec, blocking_write, sizeof(uint16_t)*(size_t)offset, in.size()*sizeof(uint16_t), (void*)(in.data()), 0, nullptr, &event);
  RtdVec::errorCheck(res, "RtdSVec::copydown - clEnqueueWriteBuffer");
  props.profiler.get("copydown")->add(event);
}

uint32_t RtdSVec::size() const
{
  cl_int errNum;
  size_t sizeBytes = 0;
  errNum = clGetMemObjectInfo(vec, CL_MEM_SIZE, sizeof(size_t), &sizeBytes, nullptr);
  RtdVec::errorCheck(errNum, "Error getting size of RtdVec");
  return sizeBytes / sizeof(uint16_t);
}

RtdSVec::RtdSVec(size_t size, GpuProps &props, bool readonly) : 
  vec_ptr(std::make_shared<cl_mem>(clCreateBuffer(props.openclContext, (readonly ? CL_MEM_READ_ONLY : CL_MEM_READ_WRITE), sizeof(uint16_t) * size, NULL, &errNum))),
  context(props.openclContext),
  vec(*vec_ptr)
{
  RtdVec::errorCheck(errNum, "RtdSVec ctor - clCreateBuffer");
}

RtdSVec::RtdSVec(const std::vector<uint16_t> &in, GpuProps &props, bool readOnly) : 
  vec_ptr(std::make_shared<cl_mem>(clCreateBuffer(props.openclContext, (readOnly ? CL_MEM_READ_ONLY : CL_MEM_READ_WRITE), sizeof(uint16_t) * in.size(), nullptr, &errNum))),
  context(props.openclContext),
  vec(*vec_ptr)
{
  RtdVec::errorCheck(errNum, "RtdSVec ctor with copy");
  cl_bool blocking_write = false;
  cl_event event;
  errNum = clEnqueueWriteBuffer(props.commandQueue, vec, blocking_write, 0, sizeof(uint16_t) * in.size(), (void *)(in.data()), 0, nullptr, &event);
  RtdVec::errorCheck(errNum, "RtdSVec ctor - clEnqueueWriteBuffer");
  props.profiler.get("copydown")->add(event);
}

RtdSVec::~RtdSVec()
{
  if (vec_ptr.use_count() > 1) 
    return;
  cl_int res = 0;
  if (vec_ptr)
    res = clReleaseMemObject(*vec_ptr);
  RtdVec::errorCheck(res, "RtdSVec::~RtdSVec - clReleaseMemObject");
}