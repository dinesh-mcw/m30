#pragma once

#include "OpenCLKernel.h"
#include "OpenCLKernels.h"
#include "RtdVec.h"
#include <vector>

// Fixed-size one-dimensional 7-point smoothing kernel.
class OpenCLSmooth7RawKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_smooth7Raw_code;
  static const char *cl_smooth7Raw_name;

public:
  OpenCLSmooth7RawKernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &in, RtdVec &out, RtdVec &k5, std::vector<uint32_t> size);
};