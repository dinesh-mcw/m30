#pragma once

#include <cstdint>
#include <memory>
#include <vector>

#include <CL/cl.h>
#include "GpuProps.h"
#include "OpenCLKernels.h"
#include "RtdVecs.h"
#include "OpenCLStaticBuffers.h"

class RawToDepthPlatform 
{
public:
    RawToDepthPlatform(int logLevel);
    ~RawToDepthPlatform();

    GpuProps &getProps() { return _gpuProps; }
    RtdVecs &getVecs() { return _vecs; }
    OpenCLKernels &getKernels() { return _kernels; }

    OpenCLStaticBuffers &getStaticBuffers() { return _staticBuffers; }

private:
    GpuProps _gpuProps;
    RtdVecs _vecs; // reusable buffers for holding data at runtime.
    OpenCLKernels _kernels;
    OpenCLStaticBuffers _staticBuffers; // Long-lived buffers e.g. image buffers
};

