#include "OpenCLTransposeRawKernel.h"
#include "OpenCLKernels.h"
#include "LumoUtil.h"

const char * OpenCLTransposeRawKernel::cl_transpose_raw_code = "\
__kernel void cl_transpose_raw(const __global float *frameBuffer,   \n\
                                     __global float *out,   \n\
                                     unsigned int inputWidth,  \n\
                                     unsigned int inputHeight,   \n\
                                     unsigned int bufferOffset) { \
  __global float *in = frameBuffer + bufferOffset;  \n\
  unsigned int work_dim = get_work_dim(); \
  if (work_dim != 2) return; \
  int x = (int)get_global_id(0); \
  int y = (int)get_global_id(1); \
  if (x >= (int)inputWidth) return;\
  if (y >= (int)inputHeight) return;\
  float3 v = vload3(x + inputWidth*y, in); \
  vstore3(v, y + inputHeight*x, out); \
}";

const char * OpenCLTransposeRawKernel::cl_transpose_raw_function_name = "cl_transpose_raw";

OpenCLTransposeRawKernel::OpenCLTransposeRawKernel(OpenCLKernels &kernels) : 
  _openCLKernel(kernels.getKernel(cl_transpose_raw_function_name, cl_transpose_raw_code))
{
}

void OpenCLTransposeRawKernel::enqueue(const RtdVec &in, RtdVec &out, std::vector<uint32_t> size, uint32_t bufferOffset)
{
  auto inputWidth = size[1];
  auto inputHeight = size[0];

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&in.vec));
  RtdVec::errorCheck(res, "OpenCLTransposeRawKernel::enqueue - arg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&out.vec));
  RtdVec::errorCheck(res, "OpenCLTransposeRawKernel::enqueue - arg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_uint), (void *)(&inputWidth)); // width
  RtdVec::errorCheck(res, "OpenCLTransposeRawKernel::enqueue - arg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(cl_uint), (void *)(&inputHeight)); // height
  RtdVec::errorCheck(res, "OpenCLTransposeRawKernel::enqueue - arg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(cl_uint), (void *)(&bufferOffset)); // offset into the frame buffer
  RtdVec::errorCheck(res, "OpenCLTransposeRawKernel::enqueue - arg 4");


  // Two dimensional size variables in RawToDepth are all Fortran/Matlab/python style {row, column}.
  // local_work_size, global_work_size are OpenCL variables, and they are {x,y,z}.
  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8,4}; 
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(inputWidth, local_work_size[0]), 
                                LumoUtil::roundToMultiple(inputHeight,local_work_size[1])};

  if (_openCLKernel->getProps().workGroupSize > 32) LumoLogErr("OpenCL workgroup size > 32.");
  if (global_work_size[1] % local_work_size[1] != 0) LumoLogErr("OpenCL local work group size mismatch in height %d is not divisible by %d.", global_work_size[1], local_work_size[1]);
  if (global_work_size[0] % local_work_size[0] != 0) LumoLogErr("OpenCL local work group size mismatch in width, %d is not divisible by %d.", global_work_size[0], local_work_size[0]);

  cl_event event;
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), 2, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLTransposeRawKernel::enqueue - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLTransposeRawKernel")->add(event);
}