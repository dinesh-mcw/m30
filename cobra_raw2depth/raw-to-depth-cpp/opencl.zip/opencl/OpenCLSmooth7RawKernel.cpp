#include "OpenCLSmooth7RawKernel.h"
#include "OpenCLKernels.h"
#include "LumoUtil.h"

const char *OpenCLSmooth7RawKernel::cl_smooth7Raw_code = "\
__kernel void cl_smooth7_raw_kernel(const __global float *in, __global float *out, const __constant float *k7, unsigned int inputWidth, unsigned int inputHeight) {\
  int work_dim = (int)get_work_dim(); \
  if (work_dim != 2) return; \
  int x = (int)get_global_id(0); /* output coords. */\
  int y = (int)get_global_id(1); \
  int outputWidth = inputWidth;\
  int outputHeight = inputHeight; \
  if (x >= outputWidth || y >= outputHeight) return; \
  int left = x-3;\
  int right = x+3;\
  int offset = left + (int)inputWidth*y; \
  float3 sum;\
  sum = vload3(offset+3, in);\
  if (left < 0 || right >= inputWidth) { vstore3(sum, offset+3, out); return; } \
  sum *= k7[3]; \
  sum += vload3(offset, in) * k7[0];\
  sum += vload3(offset+1, in) * k7[1]; \
  sum += vload3(offset+2, in) * k7[2]; \
  sum += vload3(offset+4, in) * k7[4]; \
  sum += vload3(offset+5, in) * k7[5]; \
  sum += vload3(offset+6, in) * k7[6]; \
  vstore3(sum, offset+3, out); \
} ";
const char *OpenCLSmooth7RawKernel::cl_smooth7Raw_name = "cl_smooth7_raw_kernel";

OpenCLSmooth7RawKernel::OpenCLSmooth7RawKernel(OpenCLKernels &kernels) : 
  _openCLKernel(kernels.getKernel(cl_smooth7Raw_name, cl_smooth7Raw_code))
{
}

void OpenCLSmooth7RawKernel::enqueue(RtdVec &in, RtdVec &out, RtdVec &k7, std::vector<uint32_t> size)
{
  auto inputWidth = size[1];
  auto inputHeight = size[0];

  cl_int res;
  res = clSetKernelArg(_openCLKernel->getKernel(), 0, sizeof(cl_mem), (void *)(&in.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth7RawKernel::enqueue() - clSetKernelArg 0");

  res = clSetKernelArg(_openCLKernel->getKernel(), 1, sizeof(cl_mem), (void *)(&out.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth7RawKernel::enqueue() - clSetKernelArg 1");

  res = clSetKernelArg(_openCLKernel->getKernel(), 2, sizeof(cl_mem), (void *)(&k7.vec));
  RtdVec::errorCheck(res, "OpenCLSmooth7RawKernel::enqueue() - clSetKernelArg 2");

  res = clSetKernelArg(_openCLKernel->getKernel(), 3, sizeof(unsigned int), (void *)(&inputWidth));
  RtdVec::errorCheck(res, "OpenCLSmooth7RawKernel::enqueue() - clSetKernelArg 3");

  res = clSetKernelArg(_openCLKernel->getKernel(), 4, sizeof(unsigned int), (void *)(&inputHeight));
  RtdVec::errorCheck(res, "OpenCLSmooth7RawKernel::enqueue() - clSetKernelArg 4");


  cl_uint work_dim = 2;

  size_t local_work_size[2] = {8, 4};
  size_t global_work_size[2] = {LumoUtil::roundToMultiple(inputWidth, local_work_size[0]),
                                LumoUtil::roundToMultiple(inputHeight, local_work_size[1])};

  cl_event event;  
  auto err = clEnqueueNDRangeKernel(_openCLKernel->getProps().commandQueue, _openCLKernel->getKernel(), 2, nullptr, global_work_size, local_work_size, 0, nullptr, &event);
  RtdVec::errorCheck(err, "OpenCLSmooth7RawKernel::enqueue - clEnqueuNDRangeKernel");
  _openCLKernel->getProps().profiler.get("OpenCLSmooth7RawKernel")->add(event);


}
