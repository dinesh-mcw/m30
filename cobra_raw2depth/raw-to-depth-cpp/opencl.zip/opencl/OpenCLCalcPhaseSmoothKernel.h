#pragma once

#include "OpenCLKernels.h"
#include "OpenCLKernel.h"
#include "RtdVec.h"
#include <vector>

// This operates on a buffer of 3-element float raw pixels.
class OpenCLCalcPhaseSmoothKernel
{
private:
  std::shared_ptr<OpenCLKernel> _openCLKernel;
  static const char *cl_calcPhaseSmooth_code;
  static const char *cl_calcPhaseSmooth_name;

public:
  OpenCLCalcPhaseSmoothKernel(OpenCLKernels &kernels);
  void enqueue(RtdVec &frameSmoothed, 
               RtdVec &phaseSmoothedFrame, 
               RtdVec &phaseFrame, 
               RtdVec &correctedPhaseFrame, 
               cl_uint outputSize, 
               cl_uint frameBufferOffset);
};