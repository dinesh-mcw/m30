#ifndef FACTOR 
  #define FACTOR (float(1.0F)/(float(BINNING)*float(BINNING)))
#endif
#define STRINGIFY2(X) #X
#define STRINGIFY(X) STRINGIFY2(X)

#define BIN_MXM_FUNCTION(binning, factor) " \n\
float3 bin_" STRINGIFY(binning) "x" STRINGIFY(binning) "(const __global float *in, int x_output, int y_output, int outputWidth) { \n\
  float3 sum = (float3)(0.0F, 0.0F, 0.0F);  \n\
  int inputX = x_output * " STRINGIFY(binning) ";  \n\
  int inputY = y_output * " STRINGIFY(binning) ";  \n\
  int inputPitch = outputWidth * " STRINGIFY(binning)  ";  \n\
  int inputStartIndex = inputX + inputPitch*inputY;  \n\
  for (int xIdx=0; xIdx<" STRINGIFY(binning) "; xIdx++) {  \n\
    int inputIndex = inputStartIndex;  \n\
    for (int yIdx=0; yIdx<" STRINGIFY(binning) "; yIdx++) {  \n\
      float3 a = vload3(inputIndex++, in);  \n\
      sum += a;  \n\
    }  \n\
    inputStartIndex += inputPitch;  \n\
  }  \n\
  return sum*" STRINGIFY(factor) ";  \n\
}  \n"
